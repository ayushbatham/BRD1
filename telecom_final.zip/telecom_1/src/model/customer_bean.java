package model;

public class customer_bean {	
	int id;
	String name,email,gender,aadhar,psw,psw_repeat,image,altnum;

	public customer_bean() {}
	
	public int getId() {
		return id;
	}


	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getAltnum() {
		return altnum;
	}


	public void setAltnum(String altnum) {
		this.altnum = altnum;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getAadhar() {
		return aadhar;
	}


	public void setAadhar(String aadhar) {
		this.aadhar = aadhar;
	}


	public String getPsw() {
		return psw;
	}


	public void setPsw(String psw) {
		this.psw = psw;
	}


	public String getPsw_repeat() {
		return psw_repeat;
	}


	public void setPsw_repeat(String psw_repeat) {
		this.psw_repeat = psw_repeat;
	}


	
}
