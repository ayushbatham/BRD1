package model;

public class rechargeBean {
String MRP,Validity,Calls,SMS,Data;
public void rechargeBean() {}
public String getMRP() {
	return MRP;
}
public void setMRP(String mRP) {
	MRP = mRP;
}
public String getValidity() {
	return Validity;
}
public void setValidity(String validity) {
	Validity = validity;
}
public String getCalls() {
	return Calls;
}
public void setCalls(String calls) {
	Calls = calls;
}
public String getSMS() {
	return SMS;
}
public void setSMS(String sMS) {
	SMS = sMS;
}
public String getData() {
	return Data;
}
public void setData(String data) {
	Data = data;
}


}
