package model;

public class offerBean {
	String MRP,TALKTIME, VALIDITY,TARIFF, TARIIFVALIDITY;
public offerBean() {}
public String getMRP() {
	return MRP;
}
public void setMRP(String mRP) {
	MRP = mRP;
}
public String getTALKTIME() {
	return TALKTIME;
}
public void setTALKTIME(String tALKTIME) {
	TALKTIME = tALKTIME;
}
public String getVALIDITY() {
	return VALIDITY;
}
public void setVALIDITY(String vALIDITY) {
	VALIDITY = vALIDITY;
}
public String getTARIFF() {
	return TARIFF;
}
public void setTARIFF(String tARIFF) {
	TARIFF = tARIFF;
}
public String getTARIIFVALIDITY() {
	return TARIIFVALIDITY;
}
public void setTARIIFVALIDITY(String tARIIFVALIDITY) {
	TARIIFVALIDITY = tARIIFVALIDITY;
}

}
