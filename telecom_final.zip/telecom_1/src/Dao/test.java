/*package Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class test {
	public static void main(String args[]) throws SQLException
	{
		String splan_id="1";
		
		Connection con=DBConnProvider.getdbCon();
		String sql1="select number from numbers_available where availability=? and planId=? LIMIT 1";
		PreparedStatement pst=con.prepareStatement(sql1);
		pst.setString(1, "A");
		pst.setString(2, splan_id);
		ResultSet rs=pst.executeQuery();
		
			String number=rs.getString(1);
			System.out.println(number);
		
		
	}

}
*/




package Dao;


import java.io.FileInputStream;
import java.util.Properties;

public class test {
	
//Key for 2nd part of array
/*final static int MRP = 0;
final static int TALKTIME = 1;
final static int VALIDITY = 2;
final static int TARIFF=3;
final static int TARIIFVALIDITY=4;*/
public static void main(String args[]) throws Exception {
	int status2=0;
  //get properties file
  Properties prop = new Properties();
  prop.load(new FileInputStream("C:\\Users\\NovelVox\\eclipse-workspace\\first\\telecom_1\\recharges.properties"));
 
  //get two dimensional array from the properties file that has been delineated
  int id=1;
  String[] prepaidInfos = fetchArrayFromPropFile(id,prop);

  //below code will print out all the prepaid plans
    for (int i = 0; i < prepaidInfos.length; i++) {
    	System.out.println(prepaidInfos[i]);
	  }
	  
	 
}

/*
 Creates two dimensional array from delineated string in properties file
 @param propertyName name of the property as in the file
 @param propFile the instance of the Properties file that has the property
 @return two dimensional array
*/
private static String[] fetchArrayFromPropFile(int propertyName, Properties propFile) {

  //get array split up by the semicolon
  /*String[] a = propFile.getProperty(propertyName).;*/

  //create the two dimensional array with correct size
  String[] array = new String[propertyName];

  //combine the arrays split by semicolon and comma 
  
  return array;
}


}