package Dao;
 
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import org.apache.log4j.Logger;
 
@WebServlet("/test")
public class Log4j extends HttpServlet {
 
    static final Logger LOGGER = Logger.getLogger(Log4j.class);
             
    /*public  void log() {
         
    	HttpSession session=request.getSession(false);  
 		String user=(String) session.getAttribute("activeUser");
    	
    	String s = null;
		customer_dao.username(req, rep);
    	String s1=loggs(s);
        
    }*/
    public static void loggs(String user) {
    	LOGGER.info(user+"is active");
    	
    }
 
}