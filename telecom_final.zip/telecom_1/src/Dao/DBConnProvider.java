package Dao;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnProvider {
	static String connectionUrl = "jdbc:sqlserver://NOVELVOX-PC//SQLEXPRESS;" +  
	         "databaseName=telecom";
	public static Connection getdbCon(){
		Connection con=null;
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl);
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return con;
	}

}
