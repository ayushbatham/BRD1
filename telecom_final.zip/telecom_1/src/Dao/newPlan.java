package Dao;


import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Properties;

public class newPlan {
	
//Key for 2nd part of array
final static int MRP = 0;
final static int TALKTIME = 1;
final static int VALIDITY = 2;
final static int TARIFF=3;
final static int TARIIFVALIDITY=4;
public static int prepaidToDB() throws Exception {
	int status2=0;
  //get properties file
  Properties prop = new Properties();
  prop.load(new FileInputStream("C:\\Users\\NovelVox\\eclipse-workspace\\first\\telecom_1\\db2.properties"));
 
  //get two dimensional array from the properties file that has been delineated
  String[][] prepaidInfos = fetchArrayFromPropFile("prepaid_plans",prop);
  String[][] postpaidInfos = fetchArrayFromPropFile("postpaid_plans",prop);
  String[][] broadbandInfos = fetchArrayFromPropFile("broadband_plans",prop);
  String[][] dthInfos = fetchArrayFromPropFile("dth_plans",prop);

 Connection con=DBConnProvider.getdbCon();
 String sql="delete from new_plans";
 PreparedStatement ps=con.prepareStatement(sql);
 int status=ps.executeUpdate();
  //below code will print out all the prepaid plans
    for (int i = 0; i < prepaidInfos.length; i++) {
	  if(status>0)
	  {int id=1;
		String sql1="insert into new_plans(status,MRP,TALKTIME,VALIDITY,TARIFF,TARIIFVALIDITY,planId) values(?,?,?,?,?,?,?)";
		PreparedStatement ps1=con.prepareStatement(sql1);
		ps1.setInt(1, i+1);
		ps1.setString(2, prepaidInfos[i][MRP]);
		ps1.setString(3, prepaidInfos[i][TALKTIME]);
		ps1.setString(4, prepaidInfos[i][VALIDITY]);
		ps1.setString(5, prepaidInfos[i][TARIFF]);
		ps1.setString(6, prepaidInfos[i][TARIIFVALIDITY]);
		ps1.setInt(7, id);
		ps1.executeUpdate();
		ps1.close();
	  }
	  else {
		  System.out.println("first query not executed");
	  	}
	  }
  //below code will print out all the postpaid plans  
	  for (int i = 0; i < postpaidInfos.length; i++) {
		  if(status>0)
		  {int id=2;
			String sql2="insert into new_plans(status,MRP,TALKTIME,VALIDITY,TARIFF,TARIIFVALIDITY,planId) values(?,?,?,?,?,?,?)";
			PreparedStatement ps2=con.prepareStatement(sql2);
			ps2.setInt(1, i+1);
			ps2.setString(2, postpaidInfos[i][MRP]);
			ps2.setString(3, postpaidInfos[i][TALKTIME]);
			ps2.setString(4, postpaidInfos[i][VALIDITY]);
			ps2.setString(5, postpaidInfos[i][TARIFF]);
			ps2.setString(6, postpaidInfos[i][TARIIFVALIDITY]);
			ps2.setInt(7, id);
			ps2.executeUpdate();
			/*ps2.close();*/
		  }
		  else {
			  System.out.println("second query not executed");
		  }
	  }
	  
	  for (int i = 0; i < broadbandInfos.length; i++) {
		  if(status>0)
		  {int id=3;
			String sql1="insert into new_plans(status,MRP,TALKTIME,VALIDITY,TARIFF,TARIIFVALIDITY,planId) values(?,?,?,?,?,?,?)";
			PreparedStatement ps1=con.prepareStatement(sql1);
			ps1.setInt(1, i+1);
			ps1.setString(2, broadbandInfos[i][MRP]);
			ps1.setString(3, broadbandInfos[i][TALKTIME]);
			ps1.setString(4, broadbandInfos[i][VALIDITY]);
			ps1.setString(5, broadbandInfos[i][TARIFF]);
			ps1.setString(6, broadbandInfos[i][TARIIFVALIDITY]);
			ps1.setInt(7, id);
			ps1.executeUpdate();
			ps1.close();
		  }
		  else {
			  System.out.println("third query not executed");
		  	}
		  }
	  
	  for (int i = 0; i < dthInfos.length; i++) {
		  if(status>0)
		  {int id=4;
			String sql1="insert into new_plans(status,MRP,TALKTIME,VALIDITY,TARIFF,TARIIFVALIDITY,planId) values(?,?,?,?,?,?,?)";
			PreparedStatement ps1=con.prepareStatement(sql1);
			ps1.setInt(1, i+1);
			ps1.setString(2, dthInfos[i][MRP]);
			ps1.setString(3, dthInfos[i][TALKTIME]);
			ps1.setString(4, dthInfos[i][VALIDITY]);
			ps1.setString(5, dthInfos[i][TARIFF]);
			ps1.setString(6, dthInfos[i][TARIIFVALIDITY]);
			ps1.setInt(7, id);
			ps1.executeUpdate();
			ps1.close();
			status2=1;
		  }
		  else {
			  System.out.println("fourth query not executed");
		  	}
		  }
	  ps.close();     
	  con.close();
	  return status2;
}

/*
 Creates two dimensional array from delineated string in properties file
 @param propertyName name of the property as in the file
 @param propFile the instance of the Properties file that has the property
 @return two dimensional array
*/
private static String[][] fetchArrayFromPropFile(String propertyName, Properties propFile) {

  //get array split up by the semicolon
  String[] a = propFile.getProperty(propertyName).split(";");

  //create the two dimensional array with correct size
  String[][] array = new String[a.length][a.length];

  //combine the arrays split by semicolon and comma 
  for(int i = 0;i < a.length;i++) {
      array[i] = a[i].split(",");
  }
  return array;
}


}