package Dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

public class numbers {
	public static void number() throws FileNotFoundException, IOException, SQLException {
		Properties prop = new Properties();
		  prop.load(new FileInputStream("C:\\Users\\NovelVox\\eclipse-workspace\\first\\telecom_1\\numbers.properties"));
		 
		  //get two dimensional array from the properties file that has been delineated
		  String[] prepaidInfos = fetchArrayFromPropFile("numbers_prepaid",prop);
		  /*String[] postpaidInfos = fetchArrayFromPropFile("numbers_postpaid",prop);
		  String[] broadbandInfos = fetchArrayFromPropFile("numbers_braodband",prop);
		  String[] dthInfos = fetchArrayFromPropFile("numbers_dth",prop);*/
		  for (int i = 0; i < prepaidInfos.length; i++) {
			  System.out.println(prepaidInfos[i]);
			  }
		  /*System.out.println("break");
		  for (int i = 0; i < postpaidInfos.length; i++) {
			  System.out.println(postpaidInfos[i]);
			  }
		  System.out.println("break");
		  for (int i = 0; i < broadbandInfos.length; i++) {
			  System.out.println(broadbandInfos[i]);
			  }
		  System.out.println("break");
		  for (int i = 0; i < dthInfos.length; i++) {
			  System.out.println(dthInfos[i]);
			  }*/
		  
		  Connection con=DBConnProvider.getdbCon();
		  String sql="delete from numbers_available";
		  PreparedStatement ps=con.prepareStatement(sql);
		  int status=ps.executeUpdate();
		   //below code will print out all the prepaid plans
		  for (int i = 0; i < prepaidInfos.length; i++) {
		 	  if(status>0)
		 	  {int id=1;
		 		String sql1="insert into numbers_available(planId,number,availability) values(?,?,?)";
		 		PreparedStatement ps1=con.prepareStatement(sql1);
		 		ps1.setInt(1, id);
		 		ps1.setString(2,prepaidInfos[i] );
		 		ps1.setString(3, "A");
		 		ps1.executeUpdate();
		 		
		 		
		 	  }
		 	  else {System.out.println("first query not executed");}
		 }
		String sql2="update numbers_available set availability=? where number in (select number from active_plans) ";
		PreparedStatement pst=con.prepareStatement(sql2);
		pst.setString(1, "NA");
		pst.executeUpdate(); 
  }
	
	private static String[] fetchArrayFromPropFile(String propertyName, Properties propFile) {

		  //get array split up by the semicolon
		  String[] a = propFile.getProperty(propertyName).split(",");

		  //create the two dimensional array with correct size
		  String[] array = new String[a.length];

		  //combine the arrays split by semicolon and comma 
		  for(int i = 0;i < a.length;i++) {
		      array[i] = a[i];
		  }
		  return array;
		}
}
