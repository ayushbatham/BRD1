package Dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.customer_bean;

public class customer_dao {

	public static int addCustomer(String name,String altnum,String email,String gender,String aadhar,String psw) {
		int status=0;
		Connection con=DBConnProvider.getdbCon();
		try {
			String sql="insert into dbo.customer_data(name,alternate_no,email,gender,aadhar,password) values(?,?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,name);
			ps.setString(2,altnum);
			ps.setString(3,email);
			ps.setString(4,gender);
			ps.setString(5,aadhar);
			ps.setString(6,psw);
			status=ps.executeUpdate();
			ps.close();
			con.close();
			
			
		}
		catch(Exception e) {
			System.out.println(e);
		}
		return status;
	}
	
  
	
 public static int validation(String email, String pass, HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
	 int status=0;
	 Connection con=DBConnProvider.getdbCon();
	 String name=null;
	 String image=null;
	 String id=null;
	 try {
		String sql="select id,name,email,password,image from customer_data where email=? and password=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, email);
		ps.setString(2, pass);
		ResultSet rs=ps.executeQuery();
		if(rs.next()){
			name = rs.getString("name");
			id=rs.getString("id");
			image=rs.getString("image");
			System.out.println("before session");
			HttpSession session=request.getSession();
			session.setAttribute("activeId", id);
			session.setAttribute("activeUser", name);
			session.setAttribute("activeImage", image);
			status=1;
		}
				
	} catch (Exception e) {
		System.out.println(e);
	}
	 return status;
 }
 
 public static ArrayList<customer_bean> profile(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 	ArrayList<customer_bean> data= new ArrayList<customer_bean>();
	 	Connection con=DBConnProvider.getdbCon();
	 	try {
	 		
	 		 HttpSession session=request.getSession(false);  
	 		String strid=(String) session.getAttribute("activeId");
	 		int id=Integer.parseInt(strid);
	        /* System.out.println(n);
	           String sql1="select id from customer_data where name=?";
	           PreparedStatement ps=con.prepareStatement(sql1);
	           ps.setString(1, n);
	           ResultSet rs=ps.executeQuery();
	           while(rs.next()) {
	            id=rs.getInt(1);
	           
	           }*/
	 		System.out.println(id);
	 		String sql="select name,alternate_no,email,gender,aadhar,image from customer_data where id=?";
	 		PreparedStatement pst=con.prepareStatement(sql);
	 		pst.setInt(1, id);
	 		ResultSet rs1=pst.executeQuery();
	 		
	 		while(rs1.next()) {
	 			customer_bean bean=new customer_bean();
	 			bean.setId(id);
	 			bean.setName(rs1.getString(1));
	 			System.out.println(rs1.getString(1));
	 			bean.setAltnum(rs1.getString(2));
	 			bean.setEmail(rs1.getString(3));
	 			bean.setGender(rs1.getString(4));
	 			bean.setAadhar(rs1.getString(5));
	 			bean.setImage(rs1.getString(6));
	 			data.add(bean);
	 		}
	 		
	 		/*ps.close();*/
	 		pst.close();
	 		con.close();
	 		
		} catch (Exception e) {
			System.out.println(e);
		}
	 	return data;
 	}
 
 	public static int updateCustomer(String name,String email,String gender,String alternate_no,String aadhar,HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  {
 		int status=0;
 		Connection con=DBConnProvider.getdbCon();
 		HttpSession session=request.getSession(false);
 		String strid=(String) session.getAttribute("activeId");
 		int id=Integer.parseInt(strid);
 		try {
 			String sql="Update customer_data SET name=?,alternate_no=?,email=?,gender=?,aadhar=? where id=?";
 	 		PreparedStatement ps=con.prepareStatement(sql);
 	 		ps.setString(1, name);
 	 		ps.setString(2, alternate_no);
 	 		ps.setString(3, email);
 	 		ps.setString(4, gender);
 	 		ps.setString(5, aadhar);
 	 		ps.setInt(6, id);
 	 		status=ps.executeUpdate();
 	 		} catch (Exception e) {
		System.out.println(e);
		}
 		
 		return status;
 	}
 	
 	
 	/*public static String username(HttpServletRequest req,HttpServletResponse rep)
 	{
 		HttpSession session=req.getSession(false);  
 		String user=(String) session.getAttribute("activeUser");
		return user;
 		
 	}*/
 
 
}
