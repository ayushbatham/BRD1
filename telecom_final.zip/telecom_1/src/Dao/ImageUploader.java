package Dao;

import java.io.File;
import Dao.DBConnProvider;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class ImageUploader extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final int THRESHOLD_SIZE = 1024*1204 *1; //1MB;
	private static String UPLOAD_DIR;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		boolean status = ServletFileUpload.isMultipartContent(request);
		if(status){
			System.out.println("in the program");
			//UPLOAD_DIR = getServletContext().getRealPath("uploadedImages");
			UPLOAD_DIR = "C:\\Users\\NovelVox\\eclipse-workspace\\first\\telecom_1\\WebContent\\uploadedImages";
			DiskFileItemFactory factory = new DiskFileItemFactory();
			factory.setSizeThreshold(THRESHOLD_SIZE);			
			/*FileItemFactory itemFactory = new DiskFileItemFactory();		
			((DiskFileItemFactory) itemFactory).setSizeThreshold(THRESHOLD_SIZE);*/			
			ServletFileUpload upload = new ServletFileUpload(factory);
		

			try {
				List<FileItem> items = upload.parseRequest(request);
				
				for(FileItem item : items){
					String contentType = item.getContentType();
					
					if(contentType.equals("image/png")|| contentType.equals("image/jpg") || contentType.equals("image/jpeg")){
						File saveFile = new File(UPLOAD_DIR+"/"+item.getName());
						item.write(saveFile);
						String imageName = item.getName();
						
						Connection con=DBConnProvider.getdbCon();
						String sql="select MAX(id) FROM customer_data";
						
						PreparedStatement ps=con.prepareStatement(sql);
						ResultSet rs=ps.executeQuery();
						if(rs.next()){
							int id=rs.getInt(1);
							String sql2="Update customer_data set image=? where id=?";
							PreparedStatement pst=con.prepareStatement(sql2);
							
							pst.setString(1,imageName);
							pst.setInt(2, id);
							
							if(pst.executeUpdate()>0)
							{
								response.sendRedirect(request.getContextPath()+"/front.jsp");
							}
							else{
								response.sendRedirect(request.getContextPath()+"/errorPage.jsp");
							}
							pst.close();
							
								
						}
						ps.close();
						rs.close();
						con.close();
						
						
						
						
					}else{
						out.println("Please select .png or .jpg file only.");
					}				
				}
			} catch (Exception e) {	System.out.println(); }
		}else{
			out.println("Please select atleast one file.");
		}				
	}
}



