package Dao;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;



public class newPlanFilter implements Filter {
	private FilterConfig filterConfig=null;
    public void init(FilterConfig fConfig) throws ServletException { this.filterConfig = filterConfig;}
	

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		int status=0;
		try {
			 status=newPlan.prepaidToDB();
			 numbers.number();
			 HttpServletRequest httpReq = (HttpServletRequest) request;
			    HttpServletResponse httpResp = (HttpServletResponse) response;
			    HttpSession session = httpReq.getSession();

			    String user=(String) session.getAttribute("activeUser");
			 Log4j.loggs(user);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(status>0) {
		chain.doFilter(request, response);}
		else {
			System.out.println("filter doesnot invoked");
		}
	}	
	
	public void destroy() {
		filterConfig=null;
	}
}
