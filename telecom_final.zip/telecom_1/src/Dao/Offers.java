package Dao;


import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Properties;

import model.offerBean;

public class Offers {
	
//Key for 2nd part of array
final static int MRP = 0;
final static int TALKTIME = 1;
final static int VALIDITY = 2;
final static int TARIFF=3;
final static int TARIIFVALIDITY=4;
public static ArrayList<offerBean> prepaidToDB(String planId) throws Exception {
	
  Properties prop = new Properties();
  prop.load(new FileInputStream("C:\\Users\\NovelVox\\eclipse-workspace\\first\\telecom_1\\offers.properties"));
 
  
  //get two dimensional array from the properties file that has been delineated
  String[][] prepaidInfos = fetchArrayFromPropFile("prepaid_offers",prop);
  String[][] postpaidInfos = fetchArrayFromPropFile("postpaid_offers",prop);
  String[][] broadbandInfos = fetchArrayFromPropFile("broadband_offers",prop);
  String[][] dthInfos = fetchArrayFromPropFile("dth_offers",prop);

  ArrayList<offerBean> offerList=new ArrayList<offerBean>();
  if(planId.equals("1")) {
    for (int i = 0; i < prepaidInfos.length; i++) {
	  
    	offerBean bean=new offerBean();
    	bean.setMRP(prepaidInfos[i][MRP]);
		 bean.setTALKTIME(prepaidInfos[i][TALKTIME]);
		 bean.setTARIFF( prepaidInfos[i][TARIFF]);
		 bean.setTARIIFVALIDITY(prepaidInfos[i][TARIIFVALIDITY]);
		 bean.setVALIDITY(prepaidInfos[i][VALIDITY]);
		 offerList.add(bean);
		 
    }
    }
  if(planId.equals("2")) {
	    for (int i = 0; i < postpaidInfos.length; i++) {
		  
	    	offerBean bean=new offerBean();
	    	bean.setMRP(postpaidInfos[i][MRP]);
			 bean.setTALKTIME(postpaidInfos[i][TALKTIME]);
			 bean.setTARIFF( postpaidInfos[i][TARIFF]);
			 bean.setTARIIFVALIDITY(postpaidInfos[i][TARIIFVALIDITY]);
			 bean.setVALIDITY(postpaidInfos[i][VALIDITY]);
			 offerList.add(bean);
			 
	    }
	    }
  if(planId.equals("3")) {
	    for (int i = 0; i < broadbandInfos.length; i++) {
		  
	    	offerBean bean=new offerBean();
	    	bean.setMRP(broadbandInfos[i][MRP]);
			 bean.setTALKTIME(broadbandInfos[i][TALKTIME]);
			 bean.setTARIFF( broadbandInfos[i][TARIFF]);
			 bean.setTARIIFVALIDITY(broadbandInfos[i][TARIIFVALIDITY]);
			 bean.setVALIDITY(broadbandInfos[i][VALIDITY]);
			 offerList.add(bean);
			 
	    }
	    }
  if(planId.equals("4")) {
	    for (int i = 0; i < dthInfos.length; i++) {
		  
	    	offerBean bean=new offerBean();
	    	bean.setMRP(dthInfos[i][MRP]);
			 bean.setTALKTIME(dthInfos[i][TALKTIME]);
			 bean.setTARIFF( dthInfos[i][TARIFF]);
			 bean.setTARIIFVALIDITY(dthInfos[i][TARIIFVALIDITY]);
			 bean.setVALIDITY(dthInfos[i][VALIDITY]);
			 offerList.add(bean);
			 
	    }
	    }
    return offerList;
    }

/*
 Creates two dimensional array from delineated string in properties file
 @param propertyName name of the property as in the file
 @param propFile the instance of the Properties file that has the property
 @return two dimensional array
*/
private static String[][] fetchArrayFromPropFile(String propertyName, Properties propFile) {

  //get array split up by the semicolon
  String[] a = propFile.getProperty(propertyName).split(";");

  //create the two dimensional array with correct size
  String[][] array = new String[a.length][a.length];

  //combine the arrays split by semicolon and comma 
  for(int i = 0;i < a.length;i++) {
      array[i] = a[i].split(",");
  }
  return array;
}


}