package Dao;


import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Properties;

import model.rechargeBean;

public class recharge {
	
//Key for 2nd part of array
final static int MRP = 0;
final static int TALKTIME = 1;
final static int VALIDITY = 2;
final static int TARIFF=3;
final static int TARIIFVALIDITY=4;
public static ArrayList<rechargeBean> prepaidToDB(String planId) throws Exception {
	
  Properties prop = new Properties();
  prop.load(new FileInputStream("C:\\Users\\NovelVox\\eclipse-workspace\\first\\telecom_1\\recharges.properties"));
 
  
  //get two dimensional array from the properties file that has been delineated
  String[][] prepaidInfos = fetchArrayFromPropFile("prepaid_offers",prop);
  String[][] postpaidInfos = fetchArrayFromPropFile("postpaid_offers",prop);
  String[][] broadbandInfos = fetchArrayFromPropFile("broadband_offers",prop);
  String[][] dthInfos = fetchArrayFromPropFile("dth_offers",prop);

  ArrayList<rechargeBean> offerList=new ArrayList<rechargeBean>();
  if(planId.equals("1")) {
    for (int i = 0; i < prepaidInfos.length; i++) {
	  
    	rechargeBean bean=new rechargeBean();
    	bean.setMRP(prepaidInfos[i][MRP]);
		 bean.setValidity(prepaidInfos[i][TALKTIME]);
		 bean.setCalls( prepaidInfos[i][TARIFF]);
		 bean.setSMS(prepaidInfos[i][TARIIFVALIDITY]);
		 bean.setData(prepaidInfos[i][VALIDITY]);
		 offerList.add(bean);
		 
    }
    }
  if(planId.equals("2")) {
	    for (int i = 0; i < postpaidInfos.length; i++) {
		  
	    	rechargeBean bean=new rechargeBean();
	    	bean.setMRP(prepaidInfos[i][MRP]);
			 bean.setValidity(prepaidInfos[i][TALKTIME]);
			 bean.setCalls( prepaidInfos[i][TARIFF]);
			 bean.setSMS(prepaidInfos[i][TARIIFVALIDITY]);
			 bean.setData(prepaidInfos[i][VALIDITY]);
			 offerList.add(bean);
			 
	    }
	    }
  if(planId.equals("3")) {
	    for (int i = 0; i < broadbandInfos.length; i++) {
		  
	    	rechargeBean bean=new rechargeBean();
	    	bean.setMRP(prepaidInfos[i][MRP]);
			 bean.setValidity(prepaidInfos[i][TALKTIME]);
			 bean.setCalls( prepaidInfos[i][TARIFF]);
			 bean.setSMS(prepaidInfos[i][TARIIFVALIDITY]);
			 bean.setData(prepaidInfos[i][VALIDITY]);
			 offerList.add(bean);
			 
	    }
	    }
  if(planId.equals("4")) {
	    for (int i = 0; i < dthInfos.length; i++) {
		  
	    	rechargeBean bean=new rechargeBean();
	    	bean.setMRP(prepaidInfos[i][MRP]);
			 bean.setValidity(prepaidInfos[i][TALKTIME]);
			 bean.setCalls( prepaidInfos[i][TARIFF]);
			 bean.setSMS(prepaidInfos[i][TARIIFVALIDITY]);
			 bean.setData(prepaidInfos[i][VALIDITY]);
			 offerList.add(bean);
			 
	    }
	    }
    return offerList;
    }

/*
 Creates two dimensional array from delineated string in properties file
 @param propertyName name of the property as in the file
 @param propFile the instance of the Properties file that has the property
 @return two dimensional array
*/
private static String[][] fetchArrayFromPropFile(String propertyName, Properties propFile) {

  //get array split up by the semicolon
  String[] a = propFile.getProperty(propertyName).split(";");

  //create the two dimensional array with correct size
  String[][] array = new String[a.length][a.length];

  //combine the arrays split by semicolon and comma 
  for(int i = 0;i < a.length;i++) {
      array[i] = a[i].split(",");
  }
  return array;
}


}