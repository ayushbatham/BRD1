package Dao;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebFilter("/LoginFilter")
public class LoginFilter implements Filter {

    public LoginFilter() {}


	public void destroy() {}

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpreq= (HttpServletRequest) request;
		HttpServletResponse httpres=(HttpServletResponse) response;
		HttpSession session= httpreq.getSession(false);
		String user=(String) session.getAttribute("activeUser");
		/*if(user!=null) {
		chain.doFilter(request, response);}
		else {
			httpres.sendRedirect("errorPage.jsp");
		}*/
		
		 if (session == null || session.getAttribute("activeUser") == null) {
	            httpres.sendRedirect(httpreq.getContextPath()+"/front.jsp"); // No logged-in user found, so redirect to login page.
		 } else {httpres.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
	            httpres.setHeader("Pragma", "no-cache"); // HTTP 1.0.
	            httpres.setDateHeader("Expires", 0);
	            chain.doFilter(request, response);  
	        }
	}

	
	public void init(FilterConfig fConfig) throws ServletException {}

}
