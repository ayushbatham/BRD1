package Error;


import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import Customer.*;

public class ErrorLog {
	FileWriter fileWriter;
	public ErrorLog(CustomerClass11 customerClass11) {
		try {
			fileWriter = new FileWriter("C:/Users/temp/Desktop/ErrorLog.txt",true);
			PrintWriter printWriter = new PrintWriter(fileWriter);
			printWriter.format("%s\n", customerClass11);
			printWriter.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally{
			try {
				fileWriter.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
