package Customer;

public interface CustomerClass11Dao {
	public CustomerClass11 readFromFile(String fileLocationName);
	public void tableWrite(CustomerClass11 customerClass11);

}
