package MENU;

import java.util.Scanner;

import Customer.*;

public class Menu {
	
	public static void main(String[] args){
		Scanner sc=new Scanner(System.in);
		String fileLocationName;
	    String rejectionLevel;
	    System.out.println("Please Enter File Name and Loction:-");
		fileLocationName=sc.next();
		System.out.println("Enter Rejection Level:-"); 
		System.out.println("R - if Record Level rejection is followed.");
		System.out.println("F � if File level rejection is followed.");
		rejectionLevel=sc.next();
	   CustomerClass11DaoImp read=new CustomerClass11DaoImp ();
       CustomerClass11 readFromFile =read.readFromFile(fileLocationName);
		
	}

}
