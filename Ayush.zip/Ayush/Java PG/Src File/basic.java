import java.util.Scanner; 
class Adder{
public static int add(int a, int b){
return a+b;
}
public static int add(int a, int b,int c){
return a+b+c;
}
public void non(){
System.out.println("Non Partamertized fuction running");
}
}

class basic{
public static void main(String[] args){
Scanner sc=new Scanner(System.in);
System.out.println("What You want to do");
System.out.println("1.Add Two Digits");
System.out.println("2.Add Three Digits");
System.out.println("3.Add More than Three Digits");
System.out.println("4.Non Parameterized Funtion"); 
System.out.println("5.Other");
System.out.println("Choose Your Option 1-5");
int n=sc.nextInt();

switch(n){
case 1: System.out.println("Enter two digits a and b:-");
int x=sc.nextInt();
int y=sc.nextInt();
System.out.println(Adder.add(x,y));
break;
case 2: System.out.println("Enter three digits a,b and c:-");
int p=sc.nextInt();
int q=sc.nextInt();
int r=sc.nextInt();
System.out.println(Adder.add(p,q,r)); break;
case 3: System.out.println("Enter number of digits you want to add:");
int z=sc.nextInt();
int B[]=new int[z];
System.out.println("Enter your digits");
for(int i=0;i<z;i++){
B[i]=sc.nextInt();
}
int sum=0;
for(int i=0;i<z;i++){
sum=sum+B[i];
}
System.out.println("Addition:-" +sum);
case 4: Adder obj=new Adder();
obj.non();
case 5: break;
}
}
}
