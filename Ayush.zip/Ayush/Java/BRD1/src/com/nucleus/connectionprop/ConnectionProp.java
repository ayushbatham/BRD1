package com.nucleus.connectionprop;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
public class ConnectionProp {
	
		Connection con;
		public  Connection getConnection() 
		{
		String url=null,uname=null,user=null,pass=null;
			try
			{FileReader filereader = new FileReader("connection.properties");
				Properties p=new Properties();
			        p.load(filereader);
                    url=p.getProperty("url");
                    uname=p.getProperty("uname");
                    user=p.getProperty("username");
                    pass=p.getProperty("password");
				}
				catch (FileNotFoundException e)
				{
					e.printStackTrace();
				}
				catch (IOException e)
				{
					e.printStackTrace();
				}
			try
			{
		try {
			Class.forName(url);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		con=DriverManager.getConnection(uname,user,pass);
		 con.setAutoCommit(false);  
			}
			
					catch (SQLException e) {
				
				e.printStackTrace();
			}
			return con;
		
		}
		
		public void closeConnection()
		{
		try {
			con.close();
		} catch (SQLException e) {
					e.printStackTrace();
		}	
		}
		
		

	}


