

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class UploadServelet
 */
@WebServlet("/UploadServelet")
public class UploadServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  @Override
public void init() throws ServletException {
	// TODO Auto-generated method stub
	System.out.println("--------------------");
	System.out.println("Init Method is Called" +this.getClass().getName());
	System.out.println("--------------------");
}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
     response.setContentType(arg0);
	}

}
