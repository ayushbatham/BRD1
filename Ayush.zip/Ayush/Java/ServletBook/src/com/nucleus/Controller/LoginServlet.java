package com.nucleus.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
	    session.invalidate();
	    out.println("You Are Successfully Logged Out");
	 RequestDispatcher dispatcher=request.getRequestDispatcher("login.html");
    dispatcher.include(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		//request.getRequestDispatcher("link.html").include(request,response);
		HttpSession session=request.getSession();
		String Name=request.getParameter("name");
		String Password=request.getParameter("password");
		
		if(Password.equals("Ayush@2018"))
		{
			out.print("You are successfully logged in!");
			out.print("<br>Welcome,"+ Name);
			session.setAttribute("name", Name);
			Cookie ck=new Cookie("name",Name);
			response.addCookie(ck);
			RequestDispatcher dispatcher=request.getRequestDispatcher("homepage.html");
		    dispatcher.include(request,response);
		}
		else
		{
			out.print("Sorry! invalid password, try again!");
			request.getRequestDispatcher("login.html").include(request,response);
		}
		out.close();
			
	}

}
