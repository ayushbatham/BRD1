package com.nucleus.Controller;



import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.ModelPackaeg.Book;
import com.nucleus.ModelPackaeg.BookDAO;

/**
 * Servlet implementation class BookController
 */
@WebServlet("/BookController")
public class BookController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{    
    response.setContentType("text/html");
    String action=request.getParameter("action"); //URL REWRITING
	PrintWriter out=response.getWriter();
	switch(action){
		case "1":
		{String BookName=request.getParameter("bookname");
		String Author=request.getParameter("author");
		String Title=request.getParameter("title");
		String Category=request.getParameter("categor");
		Book book=new Book();
		book.setBookname(BookName);
		book.setAuthor(Author);
		book.setTitle(Title);
		book.setCategory(Category);
		BookDAO bookDao=new BookDAO();
        bookDao.save(book);
		out.println("Book saved successfully!");
		out.println("<P align=right><a href=login.html>Logout</a><br></P>");
        out.println("<P align=right><a href=homepage.html>Go To Homepage</a><br></P>");
		break;
		}	
		case "2":
		{
		    int Id=Integer.parseInt(request.getParameter("id"));
			String BookName=request.getParameter("bookname");
			String Author=request.getParameter("author");
			String Title=request.getParameter("title");
			String Category=request.getParameter("categor");
			Book book=new Book();
			book.setId(Id);
			book.setBookname(BookName);
			book.setAuthor(Author);
			book.setTitle(Title);
			book.setCategory(Category);
			BookDAO bookDao=new BookDAO();
	        bookDao.update(book);
			out.println("Book updated successfully!");
			out.println("<P align=right><a href=login.html>Logout</a><br></P>");
			out.println("<P align=right><a href=view.html>View Update</a><br></P>");
			break;}
		case "3":{
			int Id=Integer.parseInt(request.getParameter("id"));
			Book book=new Book();
			BookDAO bookDao=new BookDAO();
	        bookDao.delete(Id);
			out.println("Book deleted successfully!");
			out.println("<P align=right><a href=login.html>Logout</a><br></P>");
			out.println("<P align=right><a href=homepage.html>Go To Homepage</a><br></P>");
			break;}
		case "4":{
			int Id=Integer.parseInt(request.getParameter("id"));
			Book book=new Book();
	        book.setId(Id);
			BookDAO bookDao=new BookDAO();
	        bookDao.getBookById(Id,book);
	        out.println("Here is the book you requested!<br>");
	        out.println("Bookid: "+book.getId()+"<br>"+"BookName: "+book.getBookname()+"<br>"+"Author: "+book.getAuthor()+"<br>"+"Title: "+book.getTitle()+"<br>"+"Category: "+book.getCategory()+"<br>");
	        out.print("\n");
	        out.println("<P align=right><a href=login.html>Logout</a><br></P>");
	        out.println("<P align=right><a href=homepage.html>Go To Homepage</a><br></P>");
	        break;}
		case "5":{
			Book b=new Book();
			BookDAO bookDao=new BookDAO();
			
		    List<Book> list = null;
			try {
				list = bookDao.getAllBooks(b);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    System.out.println(list.size());
		    out.println("<h1>Here are the book details:</h1>"+"<br>");
		    int id=0;
		    for(Book b1:list)
		    	{   
		    	id++;
		    	out.println("<h4>Entry:-"+id+"<h4/>");
		    	out.println("Book id: "+ b1.getId()+"<br>");
		    	out.println("Book Name: "+ b1.getBookname()+"<br>");
		    	out.println("Book Author: "+ b1.getAuthor()+"<br>");
		    	out.println("Book Title: "+ b1.getTitle()+"<br>");
		    	out.println("Book Category: "+ b1.getCategory()+"<br>");	
		    }
		    out.println("<P align=right><a href=login.html>Logout</a><br></P>");
		    out.println("<P align=right><a href=homepage.html>Go To Homepage</a><br></P>");
			}
		    }
	        }		
            }
