package com.nucleus.ModelPackaeg;

import java.util.*;
import java.sql.*;
public class BookDAO {
	  public static Connection getConnection(){  
	  Connection con=null;  
      try{  
		  Class.forName("oracle.jdbc.driver.OracleDriver");  
		  con=DriverManager.getConnection("jdbc:oracle:thin:@10.1.50.198:1521:orcl","sh","sh");  
		  }catch(Exception e){System.out.println(e);}  
		  return con;  
		  }  
	  public static int save(Book b){
		  int status=0;
		  Connection con= BookDAO.getConnection();
		  try {
	      PreparedStatement ps=con.prepareStatement("insert into BOOKCRUDAYUSH values (Id.nextVal,?,?,?,?)");
	    
	      ps.setString(1,b.getBookname());
		  ps.setString(2,b.getAuthor());
		  ps.setString(3,b.getTitle());
		  ps.setString(4,b.getCategory());
		  
		  status=ps.executeUpdate();
		  con.close();
		  
		  } catch (SQLException e)
		  {
			  e.printStackTrace();
		  }  return status;
		  
	  }
	  public static int update(Book b){
		  int status=0;
		  Connection con= BookDAO.getConnection();
		  try {
	      PreparedStatement ps=con.prepareStatement("update BOOKCRUDAYUSH set bookname=?,author=?,title=?,categor=? where id=?");
	      ps.setString(1,b.getBookname());
		  ps.setString(2,b.getAuthor());
		  ps.setString(3,b.getTitle());
		  ps.setString(4,b.getCategory());
		  ps.setLong(5,b.getId());
		  status=ps.executeUpdate();
		  System.out.println(status);
		  con.close();
		  
		  } catch (SQLException e)
		  {
			  e.printStackTrace();
		  }  
		  return status;
		  
	  }
	  public static int delete(int id){
		  int status=0;
		  Connection con= BookDAO.getConnection();
		  try {
	      PreparedStatement ps=con.prepareStatement("delete from BOOKCRUDAYUSH where id=?");
		  
	      ps.setLong(1,id);  
		  
		  status=ps.executeUpdate();
		  con.close();
		  
		  } catch (SQLException e)
		  {
			  e.printStackTrace();
		  }  return status;
		  
	  }
	  public static void getBookById(int id,Book book){
		
		  Connection con=BookDAO.getConnection();  
		  PreparedStatement ps;
		try {
			ps = con.prepareStatement("select * from BOOKCRUDAYUSH where id=?");
			 ps.setInt(1,id);  
		      ResultSet rs=ps.executeQuery();  
		      if(rs.next())
		      {
		    	 book.setId(rs.getInt(1));
		    	 book.setBookname(rs.getString(2));
		    	 book.setAuthor(rs.getString(3));
		    	 book.setTitle(rs.getString(4));
		    	 book.setCategory(rs.getString(5));
		    	 
		    	 con.close();
		    	  
		      }
		} catch (SQLException e) {
			e.printStackTrace();
		}
		  
	  }
	   public static List<Book> getAllBooks(Book book) throws SQLException{  
	       List<Book> list=new ArrayList<Book>();
	       Connection con= BookDAO.getConnection();
	       try {
			PreparedStatement ps=con.prepareStatement("select * from BOOKCRUDAYUSH");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Book b=new Book();
				 b.setId(rs.getInt(1));
		    	 b.setBookname(rs.getString(2));
		    	 b.setAuthor(rs.getString(3));
		    	 b.setTitle(rs.getString(4));
		    	 b.setCategory(rs.getString(5));
		    	 list.add(b);
		    	
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	       con.close();
	       return list; 
	   }
}

