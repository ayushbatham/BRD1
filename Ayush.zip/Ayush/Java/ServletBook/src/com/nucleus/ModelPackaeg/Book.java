package com.nucleus.ModelPackaeg;



public class Book {
	private int id;
	private String bookname,author,title,categor;
	public String getCategory() {
		return categor;
	}
	public void setCategory(String categor) {
		this.categor = categor;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getBookname() {
		return bookname;
	}
	public void setBookname(String bookname) {
		this.bookname = bookname;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	
}
