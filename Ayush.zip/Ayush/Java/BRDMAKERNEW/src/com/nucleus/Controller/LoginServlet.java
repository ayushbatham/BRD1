package com.nucleus.Controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
	    session.invalidate();
	    out.println("<h3>You Are Successfully Logged Out<h3>");
	    RequestDispatcher dispatcher=request.getRequestDispatcher("login.html");
        dispatcher.include(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		String Name=request.getParameter("username");
		String Password=request.getParameter("password");
		
		if(Password.equals("Ayush@2018"))
		{
			out.print("<h3>You are successfully logged in!<h3>");
			out.print("<h3><br>Welcome, "+ Name +"<h3>");
			session.setAttribute("username", Name);
			Cookie ck=new Cookie("username",Name);
			response.addCookie(ck);
			RequestDispatcher dispatcher=request.getRequestDispatcher("menu.html");
		    dispatcher.include(request,response);
		}
		else
		{
			out.print("Sorry! invalid password, try again!");
			request.getRequestDispatcher("login.html").include(request,response);
		}
		out.close();
			
	}

}
