package com.nucleus.ModelPackaeg;

public class BookDaoMain {
	
	public BookDaoMain(int bookId, String bookName, int bookPrice,
			String bookCategory) {
		super();
		this.bookId = bookId;
		this.bookName = bookName;
		this.bookPrice = bookPrice;
		this.bookCategory = bookCategory;
	}
	
	public BookDaoMain() {

	}

	private int bookId;
	private String bookName;
	private int bookPrice;
	private String bookCategory;
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public int getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}
	public String getBookCategory() {
		return bookCategory;
	}
	public void setBookCategory(String bookCategory) {
		this.bookCategory = bookCategory;
	}
	
	public BookDaoMain(String bookName, int bookPrice, String bookCategory) {
		super();
		this.bookName = bookName;
		this.bookPrice = bookPrice;
		this.bookCategory = bookCategory;
	}
	

	public BookDaoMain(int bookId) {
		super();
		this.bookId = bookId;
	}

	@Override
	public String toString() {
		return "BookDaoMain [bookId=" + bookId + ", bookName=" + bookName
				+ ", bookPrice=" + bookPrice + ", bookCategory=" + bookCategory
				+ "]";
	}
	

}
