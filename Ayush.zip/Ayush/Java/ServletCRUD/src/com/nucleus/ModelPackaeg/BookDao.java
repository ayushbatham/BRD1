package com.nucleus.ModelPackaeg;

import java.util.List;

public interface BookDao {
	public int save(BookDaoMain bookDaoMain);
	public int update(BookDaoMain bookDaoMain);
	public boolean delete(BookDaoMain bookDaoMain);
	public BookDaoMain getBookById(int bookId);
	public List<BookDaoMain> getAllBook();

}
