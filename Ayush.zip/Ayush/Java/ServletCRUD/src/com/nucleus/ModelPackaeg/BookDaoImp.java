package com.nucleus.ModelPackaeg;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.nucleus.connection.*;




public class BookDaoImp implements BookDao{
	ConnectionSetup connectionSetup=new ConnectionSetup();
	Connection con=connectionSetup.getConnection();
	PreparedStatement preparedStatement;
	
	public int save(BookDaoMain bookDaoMain) {
		 int status=0;  
		try {
			preparedStatement=con.prepareStatement("insert into BookCRUD (bId,bName,bPrice,bCategory) values (?,?,?,?)");
			  preparedStatement.setInt(1,bookDaoMain.getBookId());  
			  preparedStatement.setString(2,bookDaoMain.getBookName());  
			  preparedStatement.setInt(3,bookDaoMain.getBookPrice());  
			  preparedStatement.setString(4,bookDaoMain.getBookCategory());  
			  status=preparedStatement.executeUpdate();
			  con.close();
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
		
	}

	public int update(BookDaoMain bookDaoMain) {
		int status=0;  
        try{  
            preparedStatement=con.prepareStatement("update into BookCRUD (bId,bName,bPrice,bCategory) values (?,?,?,?)");  
            preparedStatement.setInt(1,bookDaoMain.getBookId());  
			  preparedStatement.setString(2,bookDaoMain.getBookName());  
			  preparedStatement.setInt(3,bookDaoMain.getBookPrice());  
			  preparedStatement.setString(4,bookDaoMain.getBookCategory());  
			  status=preparedStatement.executeUpdate();
			  con.close();
        }catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  return status;
}

	public boolean delete(BookDaoMain bookDaoMain) {
		boolean rowDeleted = false;
	 
    try{  
        preparedStatement=con.prepareStatement("delete from BookCRUD where bId=?");  
        preparedStatement.setInt(1,bookDaoMain.getBookId());  
        preparedStatement.executeUpdate();  
        rowDeleted =  preparedStatement.executeUpdate() > 0;  
        con.close();  
    }catch(Exception e){e.printStackTrace();}  
      
    return rowDeleted;  
}  
		// TODO Auto-generated method stub

	@Override
	public BookDaoMain getBookById(int bookId) {
            BookDaoMain bookDaoMain=new BookDaoMain();
            try{  
               preparedStatement=con.prepareStatement("select * from user905 where id=?");  
               preparedStatement.setInt(1,bookId);  
                ResultSet rs=preparedStatement.executeQuery();  
                if(rs.next()){  
                	bookDaoMain.setBookId(rs.getInt(1));  
                	bookDaoMain.setBookName(rs.getString(2));  
                	bookDaoMain.setBookPrice(rs.getInt(3));  
                	bookDaoMain.setBookCategory(rs.getString(4));  
                 }  
                con.close();  
            }catch(Exception ex){ex.printStackTrace();}  
              
            return bookDaoMain;  
	
	}

	@Override
	public List<BookDaoMain> getAllBook() {
		 List<BookDaoMain> list=new ArrayList<BookDaoMain>();  
         
	        try{  
	        preparedStatement=con.prepareStatement("select * from user905");  
	            ResultSet rs=preparedStatement.executeQuery();  
	            while(rs.next()){  
	                BookDaoMain bookDaoMain=new BookDaoMain();  
	                bookDaoMain.setBookId(rs.getInt(1));  
	                bookDaoMain.setBookName(rs.getString(2));  
	                bookDaoMain.setBookPrice(rs.getInt(3));  
	                bookDaoMain.setBookCategory(rs.getString(4));  
	                list.add(bookDaoMain);  
	            }  
	            con.close();  
	        }catch(Exception e){e.printStackTrace();}  
	          
	        return list;  
	    }  
	}
		
	
	


