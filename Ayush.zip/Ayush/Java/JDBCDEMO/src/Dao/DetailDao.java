package Dao;
import Domain.DetailsDomain;

public interface DetailDao 
{
public void saveDetails(DetailsDomain detailsDomain);
public void getDetails();
public void validateSignIn(int id1,String pwd1);

}
