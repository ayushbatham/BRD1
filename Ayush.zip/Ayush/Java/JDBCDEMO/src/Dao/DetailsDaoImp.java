package Dao;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.nucleus.connection.*; 

import Domain.DetailsDomain;

public class DetailsDaoImp implements DetailDao {
    ConnectionSetup con1=new ConnectionSetup();
    public void saveDetails(DetailsDomain detailsDomain) {
		Connection con=con1.getConnection();
	    PreparedStatement pstmt2=null;
		ResultSet resultSet=null;
		Scanner sc=new Scanner(System.in);
        try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:Oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
				pstmt2=con.prepareStatement("Select * from SIGNINSIGNUP");
				resultSet=pstmt2.executeQuery();
				pstmt2=con.prepareStatement("insert into SIGNINSIGNUP values(?,?,?,?,?)");
                pstmt2.setInt(1, userid);
				pstmt2.setString(2, fname);
		        pstmt2.setString(3, lname);
		        pstmt2.setString(4, email);
		        pstmt2.setString(5, pwd );
				int i=0;
				try{
					pstmt2.executeUpdate();
				}catch(Exception e){
					i++;
				    if(i==1){System.out.println("User Already Exists ");}
				}
				if(i==0){
					System.out.println("*****Signed Up Successfully*****");
				}
                 
			} catch (SQLException e) {

				e.printStackTrace();
			}catch (ClassNotFoundException e) {

				e.printStackTrace();
			}
             finally{
        	con1.closeConnection();
        	try {
				pstmt2.close();
				resultSet.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        	
        }

	}

	public void getDetails() {
		Connection con=con1.getConnection();
	    PreparedStatement pstmt2=null;
		ResultSet resultSet=null;
		try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:Oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
				pstmt2=con.prepareStatement("Select * from SIGNINSIGNUP");
				resultSet=pstmt2.executeQuery();
				while(resultSet.next()){
					int id=resultSet.getInt(1);
					String fname=resultSet.getString(2);
					String lname=resultSet.getString(3);
					String email=resultSet.getString(3);
					System.out.println("Userid:- "+id+"||First Name:- "+fname+"||Last Name:- "+lname+"||Email:- "+email);
					}
	        }catch (SQLException e) {
                  e.printStackTrace();
              }catch (ClassNotFoundException e) {
                    e.printStackTrace();
               }
                finally{
                       try {
                           con1.closeConnection();
                           pstmt2.close();
                           resultSet.close();
                           } catch (SQLException e) {
                                 e.printStackTrace();
                                 }
                }
		
	}

	public void validateSignIn(int id1, String pwd1) {
		Connection con=con1.getConnection();
	    PreparedStatement pstmt2=null;
		ResultSet resultSet=null;
		Scanner sc=new Scanner(System.in);
        try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:Oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
				pstmt2=con.prepareStatement("Select * from SIGNINSIGNUP");
				resultSet=pstmt2.executeQuery();
				pstmt2=con.prepareStatement("insert into SIGNINSIGNUP values(?,?,?,?,?)");
                pstmt2.setInt(1, userid);
				pstmt2.setString(2, fname);
		        pstmt2.setString(3, lname);
		        pstmt2.setString(4, email);
		        pstmt2.setString(5, pwd );
				int i=0;
				try{
					pstmt2.executeUpdate();
				}catch(Exception e){
					i++;
				    if(i==1){System.out.println("User Already Exists ");}
				}
				if(i==0){
					System.out.println("*****Signed Up Successfully*****");
				}
                 
			} catch (SQLException e) {

				e.printStackTrace();
			}catch (ClassNotFoundException e) {

				e.printStackTrace();
			}
             finally{
        	con1.closeConnection();
        	try {
				pstmt2.close();
				resultSet.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	}	
        }
	}
