package com.nucleus.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nucleus.connection.ConnectionSetup;

public class CustomerDaoImp implements CustomerDao {
	ConnectionSetup connectionsetup=new ConnectionSetup();
	Connection con=connectionsetup.getConnection();

	@Override
	public int insert(Customer cust) {
		int status=0;
		 
		 	try {
			PreparedStatement ps=con.prepareStatement("insert into BRD2 values (?,?,?,?,?,?,?,?,?,?,?,?)");
			ps.setInt(1, cust.getCustomerCode());
			ps.setString(2, cust.getCustomerName());
			ps.setString(3, cust.getCustomerAddress1());
			ps.setString(4,cust.getCustomerAddresss2());
			ps.setString(5, cust.getCustomerPincode());
			ps.setString(6, cust.getCustomerCity());
			ps.setString(7, cust.getEmailAddress());
			ps.setString(8, cust.getContactNumber());
			ps.setString(9, cust.getCreateDate());
			ps.setString(10, cust.getCreateBy());
			ps.setString(11, cust.getModifiedDate());
			ps.setString(12, cust.getModifiedBy());
			status=ps.executeUpdate();
			 
		} catch (SQLException e) {

			e.printStackTrace();
		}
		 

		return status;
	}

	@Override
	public int update(int customerCode,Customer cust) {
		int status=0;
		 
		try {
			PreparedStatement ps=con.prepareStatement("update BRD2 set cust_name=?,cust_add1=?,cust_add2=?,cust_pincode=?,cust_city=?,cust_email=?,cust_contact=?,createdate=?,createdby=?,modifieddate=?,modifiedby=? where cust_code=?");
			
			ps.setString(1, cust.getCustomerName());
			ps.setString(2, cust.getCustomerAddress1());
			ps.setString(3,cust.getCustomerAddresss2());
			ps.setString(4, cust.getCustomerPincode());
			ps.setString(5, cust.getCustomerCity());
			ps.setString(6, cust.getEmailAddress());
			ps.setString(7, cust.getContactNumber());
			ps.setString(8, cust.getCreateDate());
			ps.setString(9, cust.getCreateBy());
			ps.setString(10, cust.getModifiedDate());
			ps.setString(11, cust.getModifiedBy());
			ps.setInt(12, cust.getCustomerCode());
			status=ps.executeUpdate();
			  System.out.println(status);
			  
         } catch (SQLException e) {

			e.printStackTrace();
		}
	
		return status;
	}

	@Override
	public int delete(int custCode) {
		int status=0;
		try {
			PreparedStatement ps=con.prepareStatement("delete from BRD2 where cust_code=?");
			ps.setLong(1,custCode);
			status=ps.executeUpdate();
			 
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return status;
	}

	public Customer getCustByCode(int custCode)  {
		PreparedStatement ps;
		Customer cust=new Customer();
		try {
			ps = con.prepareStatement("select * from BRD2 where cust_code=?");
			ps.setInt(1,custCode);  
		      ResultSet rs=ps.executeQuery(); 
		     
		      if(rs.next()){
		    	  cust.setCustomerCode(rs.getInt(1));
		    	  cust.setCustomerName(rs.getString(2));
		    	  cust.setCustomerAddress1(rs.getString(3));
		    	  cust.setCustomerAddresss2(rs.getString(4));
		    	  cust.setCustomerPincode(rs.getString(5));
		    	  cust.setCustomerCity(rs.getString(6));
		    	  cust.setEmailAddress(rs.getString(7));
		    	  cust.setContactNumber(rs.getString(8));		    	 
		    	  cust.setCreateDate(rs.getString(9));
		    	  cust.setCreateBy(rs.getString(10));
		    	  cust.setModifiedDate(rs.getString(11));
		    	  cust.setModifiedBy(rs.getString(12));
		      }
		} catch (SQLException e) {

			e.printStackTrace();
		}
		return cust;
	}

	@Override
	public List<Customer> getAllCust(Customer cust) {
		 List<Customer> list=new ArrayList<Customer>();
		 PreparedStatement ps;
		try {
			ps = con.prepareStatement("select * from BRD2");
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				  Customer cust1=new Customer();
				  cust1.setCustomerCode(rs.getInt(1));
		    	  cust1.setCustomerName(rs.getString(2));
		    	  cust1.setCustomerAddress1(rs.getString(3));
		    	  cust1.setCustomerAddresss2(rs.getString(4));
		    	  cust1.setCustomerPincode(rs.getString(5));
		    	  cust1.setCustomerCity(rs.getString(6));
		    	  cust1.setEmailAddress(rs.getString(7));
		    	  cust1.setContactNumber(rs.getString(8));
		    	  cust1.setCreateDate(rs.getString(9));
		    	  cust1.setCreateBy(rs.getString(10));
		    	  cust1.setModifiedDate(rs.getString(11));
		    	  cust1.setModifiedBy(rs.getString(12));
		    	  list.add(cust1);
             }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	       return list; 
	}
}
