package com.nucleus.model;



/*Customer class file to initialize  it's variables and 
to get and set their values by getter and setter method
*/
public class Customer {
	//Initializing variables
	private int customerCode;
	private String customerName;
	private String customerAddress1;
	private String customerAddresss2;
	private String customerPincode;
	private String customerCity;
	private String emailAddress;
	private String contactNumber;
	private String createDate;
	private String createBy;
	private String modifiedDate;
	private String modifiedBy;
	
	//Getter methods to Get CustomeCode
	public int getCustomerCode() {
		return customerCode;
	}
	//Setter methods to Set ContactCode
	public void setCustomerCode(int customerCode) {
		this.customerCode = customerCode;
	}
	//Getter methods to Get CustomerName
	public String getCustomerName() {
		return customerName;
	}
	//Setter methods to Set ContactName
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	//Getter methods to Get CustomerAddress1
	public String getCustomerAddress1() {
		return customerAddress1;
	}
	//Setter methods to Set ContactAddress1
	public void setCustomerAddress1(String customerAddress1) {
		this.customerAddress1 = customerAddress1;
	}
	//Getter methods to Get CustomerAddress2
	public String getCustomerAddresss2() {
		return customerAddresss2;
	}
	//Setter methods to Set ContactAddress2
	public void setCustomerAddresss2(String customerAddresss2) {
		this.customerAddresss2 = customerAddresss2;
	}
	
	//Getter methods to Get CustomerEmail
	public String getEmailAddress() {
		return emailAddress;
	}
	//Setter methods to Set CustomerEmail
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	//Getter methods to Get CustomerContactNumber
	public String getContactNumber() {
		return contactNumber;
	}
	//Setter methods to Set ContactNumber
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	//Getter methods to Get CreateDate
	public String getCreateDate() {
		return createDate;
	}
	//Setter methods to Set CreateDate
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	//Getter methods to Get CreatedBy
	public String getCreateBy() {
		return createBy;
	}
	//Setter methods to Set CreateBy
	public void setCreateBy(String createBy) {
		this.createBy = createBy;
	}
	//Getter methods to Get ModifiedDate
	public String getModifiedDate() {
		return modifiedDate;
	}
	//Setter methods to Set ModifiedDate
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	//Getter methods to Get ModifiedBy
	public String getModifiedBy() {
		return modifiedBy;
	}
	//Setter methods to Set ModifiedBy
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

		
	//Parameterized constructor 
	
	public Customer() {
		// TODO Auto-generated constructor stub
	}

	
	@Override
	public String toString() {
		return "Customer [customerCode=" + customerCode + ", customerName="
				+ customerName + ", customerAddress1=" + customerAddress1
				+ ", customerAddresss2=" + customerAddresss2
				+ ", customerPincode=" + customerPincode + ", customerCity="
				+ customerCity + ", emailAddress=" + emailAddress
				+ ", contactNumber=" + contactNumber + ", createDate="
				+ createDate + ", createBy=" + createBy + ", modifiedDate="
				+ modifiedDate + ", modifiedBy=" + modifiedBy + "]";
	}
	public Customer(int customerCode, String customerName,
			String customerAddress1, String customerAddresss2,
			String customerPincode, String customerCity, String emailAddress,
			String contactNumber, String createDate, String createBy,
			String modifiedDate, String modifiedBy) {
		super();
		this.customerCode = customerCode;
		this.customerName = customerName;
		this.customerAddress1 = customerAddress1;
		this.customerAddresss2 = customerAddresss2;
		this.customerPincode = customerPincode;
		this.customerCity = customerCity;
		this.emailAddress = emailAddress;
		this.contactNumber = contactNumber;
		this.createDate = createDate;
		this.createBy = createBy;
		this.modifiedDate = modifiedDate;
		this.modifiedBy = modifiedBy;
	}
	public String getCustomerPincode() {
		return customerPincode;
	}
	public void setCustomerPincode(String customerPincode) {
		this.customerPincode = customerPincode;
	}
	public String getCustomerCity() {
		return customerCity;
	}
	public void setCustomerCity(String customerCity) {
		this.customerCity = customerCity;
	}
	
	

	

}
