package com.nucleus.model;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.nucleus.connection.ConnectionSetup;

public class LoginDao {
	
	ConnectionSetup connectionSetup=new ConnectionSetup();
	Connection con=connectionSetup.getConnection();
	
	public boolean toCheck(String username,String passkey)
	{
		        int flag=0;
		try {
			PreparedStatement pstmt = con.prepareStatement("Select * from USERBRD22");
			ResultSet resultSet = pstmt.executeQuery();
			while (resultSet.next())
			{
				if(username.equals((resultSet.getString(2))) && passkey.equals((resultSet.getString(3))))
				{
				flag=1;
				}
			}		
	}catch (Exception e) 
	{
	e.printStackTrace();
	}
	
if(flag==1)
	return true;
else
	return false;

	}
	public String forUser(String user){
		return user;
	}

}

