package com.nucleus.model;

import java.util.List;



public interface CustomerDao {
public int insert(Customer cust);
public int update(int customerCode,Customer cust);
public int delete(int custCode);
public Customer getCustByCode(int custCode);
public List<Customer> getAllCust(Customer cust);
}
