package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.nucleus.connection.ConnectionSetup;
import com.nucleus.model.LoginDao;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
	    session.invalidate();
	    //out.println("<p><h3>You Are Successfully Logged Out<h3><p>");
	    RequestDispatcher dispatcher=request.getRequestDispatcher("logout.jsp");
        dispatcher.include(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		HttpSession session=request.getSession();
		String Name=request.getParameter("username");
		String Password=request.getParameter("password");
		LoginDao loginDao=new LoginDao();
		ConnectionSetup connectionSetup=new ConnectionSetup();
		@SuppressWarnings("unused")
		Connection con=connectionSetup.getConnection();
		if(loginDao.toCheck(Name, Password))
		{
			
			session.setAttribute("username", Name);
			Cookie ck=new Cookie("username",Name);
			response.addCookie(ck);
			request.setAttribute("u", Name);
			
			RequestDispatcher dispatcher=request.getRequestDispatcher("menu.jsp");
		    dispatcher.include(request,response);
		}
		else
		{
			out.print("Sorry! invalid password, try again!");
			request.getRequestDispatcher("login.jsp").include(request,response);
		}
		out.close();
			
	}

}
