package com.nucleus.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.model.Customer;
import com.nucleus.model.CustomerDao;
import com.nucleus.model.CustomerDaoImp;
import com.nucleus.model.LoginDao;

/**
 * Servlet implementation class AccountController
 */
@WebServlet("/AccountController")
public class AccountController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AccountController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
	    String action=request.getParameter("action"); //URL REWRITING
		PrintWriter out=response.getWriter();
		switch(action){
			case "1":
			{
				RequestDispatcher dispatcher=request.getRequestDispatcher("menu.jsp");
			    dispatcher.include(request,response);
				LoginDao loginDao=new LoginDao();
				long millis=System.currentTimeMillis();  
				java.sql.Date date=new java.sql.Date(millis); 
		        Format formatter = new SimpleDateFormat("yyyy-MM-dd");
		        String CreateDate = formatter.format(date);
            int CustomerCode=Integer.parseInt(request.getParameter("custCode"));
			String CustomerName=request.getParameter("custName");
			String CustAdd1=request.getParameter("custAdd1");
			String CustAdd2=request.getParameter("custAdd2");
			String CustPin=request.getParameter("pinCode");
			String CustCity=request.getParameter("City");
			String Email=request.getParameter("email");
			String Contact=request.getParameter("custContact");
			//String CreatedBy=request.getParameter("custName");
            Customer cust=new Customer();
			cust.setCustomerCode(CustomerCode);
			cust.setCustomerName(CustomerName);
			cust.setCustomerAddress1(CustAdd1);
			cust.setCustomerAddresss2(CustAdd2);
			cust.setCustomerPincode(CustPin);
			cust.setCustomerCity(CustCity);
			cust.setEmailAddress(Email);
			cust.setContactNumber(Contact);
			cust.setCreateDate(CreateDate);
			cust.setCreateBy(CustomerName);
			CustomerDao customerDao=new CustomerDaoImp();
			int result=customerDao.insert(cust);
			if(result==0){
	        	System.out.println(result);
	        	 out.println("<p><h3>Account Already Exists</h3></p>");
	        }
	        else{
            out.println("<P><h3>Details saved successfully!</h3></P>");
	        } 
			break;
			}	
			case "2":
			{  
				
			    Customer cust=new  Customer();
			    CustomerDao customerDao=new CustomerDaoImp();
			    int CustomerCode=Integer.parseInt(request.getParameter("custCode"));
			    System.out.println(CustomerCode);
			    cust.setCustomerCode(CustomerCode);
			    Customer customer=customerDao.getCustByCode(CustomerCode);
			    request.setAttribute("cust", customer);
			    if(customer.getCustomerCode()==0){
			    	RequestDispatcher dispatcher=request.getRequestDispatcher("menu.jsp");
				    dispatcher.include(request,response);
		        	out.println("<p><h3>Account Doesn't Exists </h3></p>");	
		            //out.println("<p align=right><a href=menu.jsp>Go To Home Page</a></p>");
		        }else{
		        	RequestDispatcher dispatcher=request.getRequestDispatcher("update.jsp");
			    dispatcher.include(request, response);
		        }
		      break;}
			case "3":{
				
				RequestDispatcher dispatcher=request.getRequestDispatcher("menu.jsp");
			    dispatcher.include(request,response);
				Customer cust=new Customer();
				long millis=System.currentTimeMillis();  
				java.sql.Date date=new java.sql.Date(millis); 
		        Format formatter = new SimpleDateFormat("yyyy-MM-dd");
		        String ModifiedDate = formatter.format(date);
				int CustomerCode=Integer.parseInt(request.getParameter("custCode"));
				String CustomerName=request.getParameter("custName");
				String CustAdd1=request.getParameter("custAdd1");
				String CustAdd2=request.getParameter("custAdd2");
				String CustPin=request.getParameter("pinCode");
				String CustCity=request.getParameter("City");
				String Email=request.getParameter("email");
				String Contact=request.getParameter("custContact");
				String CreateDate=request.getParameter("custCreateDate");
				String CreateBy=request.getParameter("custCreateBy");
				//String ModifiedBy=request.getParameter("custName");
              
               
				cust.setCustomerCode(CustomerCode);
				cust.setCustomerName(CustomerName);
				cust.setCustomerAddress1(CustAdd1);
				cust.setCustomerAddresss2(CustAdd2);
				cust.setCustomerPincode(CustPin);
				cust.setCustomerCity(CustCity);
				cust.setEmailAddress(Email);
				cust.setContactNumber(Contact);
				cust.setCreateDate(CreateDate);
				cust.setCreateBy(CreateBy);
				cust.setModifiedDate(ModifiedDate);
				cust.setModifiedBy(CustomerName);
				CustomerDao customerDao=new CustomerDaoImp();
		       customerDao.update(CustomerCode,cust);
		        
		        	out.println("<p><h3>Details updated successfully!</h3></p>");
		        
			
              
		        
              break;}
			case "4":{
				
				int CustomerCode=Integer.parseInt(request.getParameter("custCode"));
				@SuppressWarnings("unused")
				Customer cust=new Customer();
				CustomerDao customerDao=new CustomerDaoImp();
		        int flag=customerDao.delete(CustomerCode);
		        if(flag==1){
		        	RequestDispatcher dispatcher=request.getRequestDispatcher("menu.jsp");
				    dispatcher.include(request,response);
		        	out.println("<p><h3>Account with Customer Code: "+CustomerCode+" Deleted successfully!</h3></p>");	
		        }
		        else{
		        	RequestDispatcher dispatcher=request.getRequestDispatcher("menu.jsp");
				    dispatcher.include(request,response);
		        	out.println("<p><h3>Account Doesn't Exists </h3></p>");
		        }
				
				 
              break;}
			case "5":{
				
                int CustomerCode=Integer.parseInt(request.getParameter("custCode"));
				Customer cust=new Customer();
				CustomerDao customerDao=new CustomerDaoImp();
		        cust=customerDao.getCustByCode(CustomerCode);
		        if(cust.getCustomerName()==null){
		        	RequestDispatcher dispatcher=request.getRequestDispatcher("menu.jsp");
				    dispatcher.include(request,response);
		        	out.println("<p><h3>Account Doesn't Exists </h3></p>");	
		           
		        }
		        else {
		        request.setAttribute("cust", cust);
		        RequestDispatcher dispatcher=request.getRequestDispatcher("showbyid.jsp");
			    dispatcher.include(request, response);
		        }
		        break;
				}
			
			case "6":{
				
                Customer cust=new Customer();
				CustomerDao customerDao=new CustomerDaoImp();
                List<Customer> list = customerDao.getAllCust(cust);
			    System.out.println(list.size());
			    request.setAttribute("list", list);
			     RequestDispatcher dispatcher=request.getRequestDispatcher("showall.jsp");
			    dispatcher.include(request, response);
			    
			    /*out.println("<h1>Here are the Customer details:</h1>"+"<br>");
			    int id=0;
			   for(Customer c1:list)
			    	{   
			    	id++;
			    	out.println("<h4>Entry:-"+id+"<h4/>");
			    	out.println("Customer Code: "+ c1.getCustomerCode()+"<br>");
			    	out.println("Customer Name: "+ c1.getCustomerName()+"<br>");
			    	out.println("Primary Address: "+ c1.getCustomerAddress1()+"<br>");
			    	out.println("Secondary Address: "+ c1.getCustomerAddresss2()+"<br>");
			    	out.println("Pin Code: "+ c1.getCustomerCode()+"<br>");
			    	out.println("City: "+ c1.getCustomerCity()+"<br>");
			    	out.println("Email Address: "+ c1.getEmailAddress()+"<br>");
			    	out.println("Contact Number: "+ c1.getContactNumber()+"<br>");
			    	out.println("Create Date: "+ c1.getCreateDate()+"<br>");
			    	out.println("Create By: "+ c1.getCreateBy()+"<br>");
			    	out.println("Modified Date: "+ c1.getModifiedDate()+"<br>");
			    	out.println("Modified By: "+ c1.getModifiedBy()+"<br>");
			    	
			    }
			    out.println("<p align=right><a href=menu.jsp>Go To Home Page</a></p>");*/
			}
			    }
		        }		
	}


