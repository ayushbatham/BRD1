package com.nucleus.dao;

import java.util.List;

import com.nucleus.ModelPackege.Book;

public interface BookDao {
	public void addBook( Book book );
	public void deleteBook( int bookId );
	public void updateBook( Book book );
	public List<Book> getAllBooks();
	public Book getBookById( int bookId );

}
