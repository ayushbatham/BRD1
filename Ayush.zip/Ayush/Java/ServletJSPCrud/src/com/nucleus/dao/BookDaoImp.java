package com.nucleus.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.nucleus.ModelPackege.Book;
import com.nucleus.connection.ConnectionSetup;


public class BookDaoImp implements BookDao{
	ConnectionSetup connectionSetup=new  ConnectionSetup();
	Connection con=connectionSetup.getConnection();
	
	

	@Override
	public void addBook(Book book) {
		try {
			String query = "insert into BOOKAYUSHCRUD (BID, BName, BPRICE, BCATEGORY) values (?,?,?,?)";
			PreparedStatement preparedStatement = con.prepareStatement( query );
			preparedStatement.setInt( 1, book.getBookId() );
			preparedStatement.setString( 2, book.getBookName() );
			preparedStatement.setFloat( 3, book.getBookPrice() );
			preparedStatement.setString( 4, book.getBookCategory() );
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
		


	@Override
	public void deleteBook(int bookId) {
		try {
			String query = "delete from BOOKAYUSHCRUD where BID=?";
			PreparedStatement preparedStatement= con.prepareStatement( query );
			preparedStatement.setInt(1, bookId);
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
			}
		
	}

	@Override
	public void updateBook(Book book) {
		try {
			String query = "update BOOKAYUSHCRUD set BNAME=?, BPRICE=?, BCATEGORY=? where BID=?";
			PreparedStatement preparedStatement = con.prepareStatement( query );
			preparedStatement.setString( 1, book.getBookName() );
			preparedStatement.setFloat( 2, book.getBookPrice() );
			preparedStatement.setString( 3, book.getBookCategory() );
			preparedStatement.setInt( 4, book.getBookId() );
			preparedStatement.executeUpdate();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	@Override
	public List<Book> getAllBooks() {
		List<Book> books = new ArrayList<Book>();
		try {
			Statement statement = con.createStatement();
			ResultSet resultSet = statement.executeQuery( "select * from BOOKAYUSHCRUD" );
			while( resultSet.next() ) {
				Book book= new Book();
				book.setBookId( resultSet.getInt( "bookId" ) );
				book.setBookName( resultSet.getString( "bookName" ) );
				book.setBookPrice( resultSet.getFloat( "bookPrice" ) );
				book.setBookCategory( resultSet.getString( "bookCategory" ) );
			    books.add(book);
			}
			resultSet.close();
			statement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return books;
	}

	@Override
	public Book getBookById(int bookId) {
		Book book = new Book();
		try {
			String query = "select * from BOOKAYUSHCRUD where BID=?";
			PreparedStatement preparedStatement = con.prepareStatement( query );
			preparedStatement.setInt(1, bookId);
			ResultSet resultSet = preparedStatement.executeQuery();
			while( resultSet.next() ) {
				book.setBookId( resultSet.getInt( "bookId" ) );
				book.setBookName( resultSet.getString( "bookName" ) );
				book.setBookPrice( resultSet.getFloat( "bookName" ) );
				book.setBookCategory( resultSet.getString( "bookCategory" ) );
				
			}
			resultSet.close();
			preparedStatement.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return book;
	}

}
