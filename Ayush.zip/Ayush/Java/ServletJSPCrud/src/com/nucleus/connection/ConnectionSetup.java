package com.nucleus.connection;
//Program to create Connection
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
//public class to setup connection
public class ConnectionSetup 
{
	Connection con;
	
	//Method to get connection
	public  Connection getConnection()
	{
		Properties p=new Properties();
	try {
		p.load(this.getClass().getResourceAsStream("Connection.properties"));
	Class.forName(p.getProperty("url"));
	con=DriverManager.getConnection(p.getProperty("key"),p.getProperty("username"),p.getProperty("password"));

	}
		catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
	catch (SQLException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		return con;
    }
	
	//Method To close connection
    public void closeConnection()
	{
	try {
		con.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	}
	
	

}
