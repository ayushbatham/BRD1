package com.nucleus.ModelPackege;

public class Book {
private int bookId;
private String bookName;
private float bookPrice;
private String bookCategory;
private String bookDesc;
public Book() {
	// TODO Auto-generated method stub

}
public int getBookId() {
	return bookId;
}
public void setBookId(int bookId) {
	this.bookId = bookId;
}
public String getBookName() {
	return bookName;
}
public void setBookName(String bookName) {
	this.bookName = bookName;
}
public float getBookPrice() {
	return bookPrice;
}
public void setBookPrice(float bookPrice) {
	this.bookPrice = bookPrice;
}
public String getBookCategory() {
	return bookCategory;
}
public void setBookCategory(String bookCategory) {
	this.bookCategory = bookCategory;
}
public String getBookDesc() {
	return bookDesc;
}
public void setBookDesc(String bookDesc) {
	this.bookDesc = bookDesc;
}
@Override
public String toString() {
	return "Book [bookId=" + bookId + ", bookName=" + bookName + ", bookPrice="
			+ bookPrice + ", bookCategory=" + bookCategory + ", bookDesc="
			+ bookDesc + "]";
}
public Book(int bookId, String bookName, float bookPrice, String bookCategory,
		String bookDesc) {
	super();
	this.bookId = bookId;
	this.bookName = bookName;
	this.bookPrice = bookPrice;
	this.bookCategory = bookCategory;
	this.bookDesc = bookDesc;
}

}
