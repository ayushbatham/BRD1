package com.nucleus.Controller;


import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.ModelPackege.Book;
import com.nucleus.dao.BookDaoImp;

/**
 * Servlet implementation class BookController
 */
@WebServlet("/BookController")
public class BookController extends HttpServlet {
	private BookDaoImp dao;
	private static final long serialVersionUID = 1L;
	public static final String lIST_BOOK = "/listBook.jsp";
	public static final String INSERT_OR_EDIT = "/book.jsp";   
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookController() {
    	dao = new BookDaoImp();
       
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//BookDaoImp dao = new BookDaoImp();
		String forward = "";
		String action = request.getParameter( "action" );

		if( action.equalsIgnoreCase( "delete" ) ) {
			forward = lIST_BOOK;
			int bookId = Integer.parseInt( request.getParameter("bookId") );
			dao.deleteBook(bookId);
			request.setAttribute("books", dao.getAllBooks() );
		}
		else if( action.equalsIgnoreCase( "edit" ) ) {
			forward = INSERT_OR_EDIT;
			int bookId = Integer.parseInt( request.getParameter("bookId") );
			Book book=dao.getBookById(bookId);
			request.setAttribute("book", book);
		}
		else if( action.equalsIgnoreCase( "insert" ) ) {
			forward = INSERT_OR_EDIT;
		}
		else {
			forward = lIST_BOOK;
			request.setAttribute("books", dao.getAllBooks() );
		}
		RequestDispatcher view = request.getRequestDispatcher( forward );
		view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Book book=new Book();
		book.setBookName( request.getParameter( "bookName" ) );
		book.setBookPrice( Float.parseFloat(request.getParameter( "bookPrice" ) ));
		book.setBookCategory( request.getParameter( "bookCategory" ) );
	    String bookId = request.getParameter("bookId");

		if( bookId == null || bookId.isEmpty() )
			dao.addBook(book);
		else {
			book.setBookId( Integer.parseInt(bookId) );
			dao.updateBook(book);
		}
		RequestDispatcher view = request.getRequestDispatcher( lIST_BOOK );
		request.setAttribute("books", dao.getAllBooks());
		view.forward(request, response);
	}

}
