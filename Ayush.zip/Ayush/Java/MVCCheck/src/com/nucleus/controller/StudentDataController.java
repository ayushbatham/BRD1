package com.nucleus.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.nucleus.modelPackage.StudentDataDao;
import com.nucleus.modelPackage.StudentDataDaoImp;
import com.nucleus.modelPackage.StudentDomain;

/**
 * Servlet implementation class StudentDataController
 */
@WebServlet("/StudentDataController")
public class StudentDataController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentDataController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
                String stname=request.getParameter("stname");
                String fname=request.getParameter("fname");
                String mname=request.getParameter("mname");
                String adr=request.getParameter("adr");
                String cname=request.getParameter("cname");
                StudentDomain studentDomain=new StudentDomain();
                studentDomain.setStname(stname);
                studentDomain.setFname(fname);
                studentDomain.setMname(mname);
                studentDomain.setAdr(adr);
                studentDomain.setCname(cname);
                StudentDataDao studentDataDao=new StudentDataDaoImp();
                studentDataDao.SaveData();
                RequestDispatcher requestDispatcher=request.getRequestDispatcher("Success");
                requestDispatcher.forward(request, response);
	}

}
