package com.nucleus.modelPackage;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;

import com.nucleus.Customer.CustomerClass11;
import com.nucleus.Validation.ValidationCheck;
import com.nucleus.connection.ConnectionSetup;

public class StudentDataDaoImp implements StudentDataDao {
	FileReader fileReader;
	ValidationCheck validation=new ValidationCheck();
    PreparedStatement preparedStatement;
    CustomerClass11 customerClass11;
    ConnectionSetup connectionsetup=new ConnectionSetup();
	Connection con=connectionsetup.getConnection();

	@Override
	public void SaveData() {
		System.out.println("Data Saved");
		
	}

}
