package com.nucleus.modelPackage;

public interface StudentDataDao {
public void SaveData();
}
