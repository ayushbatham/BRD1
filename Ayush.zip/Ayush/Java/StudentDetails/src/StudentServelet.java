

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentServelet
 */
@WebServlet("/StudentServelet")
public class StudentServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StudentServelet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			response.setContentType("text/html");
			StudentPercentageAndGrade st=new StudentPercentageAndGrade();
		PrintWriter out = response.getWriter();
	    String r = request.getParameter("rollno");
        String n = request.getParameter("stname");
        int m = Integer.parseInt(request.getParameter("marks"));
        int mm = 100;
       float perc=st.calcPerc(m, mm);
       out.println("<table>Roll Number:-"+r+"</table>");
       out.println("<table>Student's Name:-"+n+"</table>");
       out.println("<table><Percentage is:-"+perc+"</table>");
       char grade=st.calcGrade(perc);
       out.println("<table>Grade:-"+grade+"</table>");
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		super.doPost(request, response);
	}

}
