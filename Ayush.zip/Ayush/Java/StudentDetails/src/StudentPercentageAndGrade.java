
public class StudentPercentageAndGrade {
	public float calcPerc(int m,int mm){
		float perce=(m*100/mm);
		return perce;
    }
	public char calcGrade(float perc){
		char grade = 0;
	       if(perc>0&&perc<=30){
	    	   grade='E';
	       }
	       else if(perc>31&&perc<=40){
	    	   grade='D';
	       }
	       else if(perc>41&&perc<=60){
	    	   grade='C';
	       }
	       else if(perc>61&&perc<=80){
	    	   grade='B';
	       }
	       else {
	    	   grade='A';
	    	   }
		return grade;
		
	}
	

}
