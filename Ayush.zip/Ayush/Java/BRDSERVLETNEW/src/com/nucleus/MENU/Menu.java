/*package com.nucleus.MENU;

import java.util.Scanner;

import com.nucleus.Customer.*;
Menu Program to take FileLocation and File Name from User
to upload data in database
public class Menu {   //Menu Class
	//Main Method
	public static void main(String[] args){  
		@SuppressWarnings("resource")
		Scanner sc=new Scanner(System.in);
		String fileLocationName;
	    @SuppressWarnings("unused")
		String rejectionLevel;
	    //Taking File name and it's location from user
	    System.out.println("Please Enter File Name and Loction:-");
		fileLocationName=sc.next();
		//Taking rejection Level from user
		System.out.println("Enter Rejection Level:-"); 
		System.out.println("R - if Record Level rejection is followed.");
		System.out.println("F � if File level rejection is followed.");
		rejectionLevel=sc.next();
		//Object Creation
	    CustomerClass11DaoRdbms read=new CustomerClass11DaoRdbms ();
        @SuppressWarnings("unused")
        //Passing filelocation to readFromFile method
	    CustomerClass11 readFromFile =read.readFromFile(fileLocationName,rejectionLevel);
	   
	}

}
*/