import modifier.mod;


public class checkmod extends mod //inherit mod class from other package to access protected member of mod class 
{

	public static void main(String[] args) {
		
			checkmod obj=new checkmod();
			obj.display1();//will not work becoz it can't access method of default class from another package
			obj.display2();//will work becoz modifier of method is public
			obj.display3();//will work becoz modifier of method is protected and class is inherited
			obj.display4();//will not access private members of mod class
			
		

	}

}
