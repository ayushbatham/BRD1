

import constructor.Student;
public class checkchaining //check constructor chaining
{

	public static void main(String[] args) {
		new Student();//calling no argument constructor from Student.java
	}

}
