import constructor.overlo;


public class overlcheck //check constructor overloading
{

	public static void main(String[] args) {
		new overlo();//calling no argument constructor;
		new overlo(5);//calling single argument constructor
		new overlo(6,7);//calling two argument constructor
		new overlo(5,8,9);//calling three argument constructor

	}

}
