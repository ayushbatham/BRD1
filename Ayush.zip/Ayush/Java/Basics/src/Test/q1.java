package Test;
import java.util.*;
public class q1 {

	int sum=0,l=0;
	float avg=0;
	long k;
    public void Player(int n,String[] detail){
		String st="";		
			for(int i=0;i<detail.length;i++){
			    st=detail[i];
			    long a=Long.parseLong(st);
			    while(a>0)
			    {
			    	k=a%10;
			    	sum=(int) (sum+k);
			    	a=a/10;
			    }
			    avg=sum/3;
			    sum=0;
			    }
			if(avg>=5){
				l++;
			}
			System.out.println("Number Of Best Players are:-"+l);
		}
public static void main(String[] args) {
System.out.println("Enter Number Of Players:");
Scanner sc=new Scanner(System.in);
int n=sc.nextInt();
String[] detail=new String[n];
System.out.println("Enter player's details");
for(int i=0;i<n;i++){
	detail[i]=sc.next();
}
q1 obj=new q1();
obj.Player(n, detail);

sc.close();
}
}
