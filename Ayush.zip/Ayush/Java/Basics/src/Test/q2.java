package Test;

import java.util.ArrayList;
import java.util.List;

public class q2 {
public void check(int n,int ...sc){
	int num=sc.length;
	for(int i=0;i<=num;i++){
		sc[i+1]=sc[i+2];
		
	}
	
}
	public static void main(String[] args) {
		List l1=new ArrayList();
		System.out.println("Enter Score");
		int[] sc={1,3,4,5,5,6,8};
q2 obj=new q2();
obj.check(sc.length, sc);

	}

}
