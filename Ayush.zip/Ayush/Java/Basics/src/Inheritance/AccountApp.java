package Inheritance;
/*Java Program to understand Inheritance
 * Program will give Account details entered by user
 */
class Account //Parent class of Saving And Current Accounts
{
	public void DisplayAccountDetails()//will display Account Details
	{
		System.out.println("Account Details");
		SavingAccount.CalInterest();
	}
	
	
}
class SavingAccount extends Account//Child class of Accounts
{
	public void DisplayAccountDetails(){
		System.out.println("Saving Account");
		
	}
	public static void CalInterest(){
		System.out.println("Calculate Interest");
	} 
	public void ShowBalance(){
		System.out.println("Show Saving Balance");
	}
}
class CurrentAccount extends Account{
	public void DisplayAccountDetails(){
		System.out.println("Current Account");
	}
	public void ShowBalance(){
		System.out.println("Show Current Account Balance");
	}
}
public class AccountApp{
	public static void main(String[] args) {
		Account ac1=new SavingAccount();//upcasting
		Account ac2=new CurrentAccount();//upcasting
		ac1.DisplayAccountDetails();
	    SavingAccount sa=(SavingAccount) ac1;//Downcasting
		sa.CalInterest();
		sa.ShowBalance();
		ac2.DisplayAccountDetails();
		CurrentAccount ca=(CurrentAccount) ac2;//Downcast
		ca.ShowBalance();
		

		
	}
}

