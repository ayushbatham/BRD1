package FileHandling;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;


public class SampleFileHandling1{
	static int id;
	static String name,dept;
	public void saveTofile(Student[] str){
		FileWriter fileWriter=null;
		PrintWriter printWriter=null;
	try{
fileWriter=new FileWriter("Sample1.txt",true);
printWriter=new PrintWriter(fileWriter);
	printWriter.write(str+"\n");
	printWriter.flush();
	}catch(IOException e){
		e.printStackTrace();
	}finally{
		try{
			fileWriter.close();
		}catch(IOException e){
			e.printStackTrace();
		}
		}
	}
	public void readFromFile(){
		FileReader fileReader=null;
		BufferedReader bufferedReader=null;
		try{
            fileReader=new FileReader("Sample1.txt");
			bufferedReader=new BufferedReader(fileReader);
			try {
				String print=bufferedReader.readLine();
				while(print!=null){
					System.out.println(print);
					print=bufferedReader.readLine();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}
		finally{
			try {
				fileReader.close();
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}

public static void main(String[] args){
	Scanner sc=new Scanner(System.in);
	System.out.println("How Many details You want to enter???");
	int n=sc.nextInt();
	Student[] str = null;
	for(int i=0;i<n;i++){
		System.out.println("Enter Id");
		id=sc.nextInt();
		System.out.println("Enter Name");
		name=sc.next();
		System.out.println("Enter Department");
		dept=sc.next();
		//str[i]=new Student(id,name,dept);
	}
	for(int j=0;j<n;j++){
		SampleFileHandling1 sampleFileHandling1=new SampleFileHandling1();
	//sampleFileHandling1.saveTofile(str[j]);
		sampleFileHandling1.readFromFile();
	}
	sc.close();
}
}
