package FileHandling;

public class Student {
	public int id;
	public String name;
	public String dept;

public Student(int id2, String name2, String dept2) {
	id=id2;
	name=name2;
	dept=dept2;
}


}
