package Collection;

public class Student11{
	int id;
	String name;
	String dept;

	public void Student11(){
	}
	public void Student11(String name,int id,String dept) {
		this.name=name;
		this.id=id;
		this.dept=dept;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getName() {
		return name;
	}
    public void setId(int id) {
	this.id = id;
}
    public int getId() {
	return id;
}
    public void setDept(String dept) {
	this.dept = dept;
}
    public String getDept() {
	return dept;
}

}