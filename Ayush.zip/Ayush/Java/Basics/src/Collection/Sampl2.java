package Collection;
import java.util.*;

public class Sampl2  {
	

	public static void main(String[] args){
		
		Scanner sc=new Scanner(System.in);
		System.out.println("What You want to choose");
		System.out.println("Choose From 1-3");
		System.out.println("1.For ArrayList");
		System.out.println("2.For Linked List");
		System.out.println("3.For Hash Set");
		int choice=sc.nextInt();
		switch(choice){
		
		case 1:{
			ArrayList1 ar=new ArrayList1();
		    ar.forArrayList();
		    break;
			}
		case 2:{
			LinkedList1 lr=new LinkedList1();
			lr.forLinkedList();
			break;
	        }
		case 3:{
			System.out.println("Code is Not Written");
			break;
		}
		default :
			break;
	   }
		
   }
}

	 
	 
		


