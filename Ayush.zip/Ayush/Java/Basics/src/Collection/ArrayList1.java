package Collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class ArrayList1  {
	Student11 s1;
	static int id;
	static String naam;
	static String dept;
	Scanner sc=new Scanner(System.in);
	ArrayList <Student11>l1=new ArrayList<Student11>();
	public void setAllData(){
		System.out.println("Enter Number of Students:-");
		int numStudent=sc.nextInt();
        for(int i=0;i<numStudent;i++){
		s1=new Student11();
		System.out.println("Enter Name:-");
		naam=sc.next();
		s1.setName(naam);
		System.out.println("Enter ID:-");
		id=sc.nextInt();
		s1.setId(id);
		System.out.println("Enter Department:-");
		dept=sc.next();
		s1.setDept(dept);
		s1.Student11(naam,id,dept);
		l1.add(s1);
		}
	}
	public void getAllData(){
	Iterator<Student11> itr=l1.iterator();
        while(itr.hasNext()){
        Student11 st=(Student11)itr.next();	
	        System.out.println(" Name:-"+st.getName()+"|ID:- "+st.getId()+"|Dept:- "+st.getDept());
		}
	}
	
public void forArrayList(){
	int i=1;
    while(i==1){
    System.out.println("What You Want To Do");
	System.out.println("Enter You Choice From 1-3");
	System.out.println("1.Add Students Data");
	System.out.println("2.Remove Student Data");
	System.out.println("3.Display Student Data");
	System.out.println("***************************");
	int choice=sc.nextInt();
	ArrayList1 ar2=new ArrayList1(); 
	
	switch(choice){
	case 1:{
		ar2.setAllData();
	System.out.println("Want to Display Your List?? Enter 1 For Yes");
	int ch=sc.nextInt();
	switch (ch) {
	case 1:
		ar2.getAllData();
		break;
    default:
		break;
	}
	break;
	}
    case 2:{
    	
		break;
	}
	case 3:{
	ar2.getAllData();
		break;
	}
	}
	i--;
	System.out.println("Want to Continue?? Enter 1 for Yes");
	i=sc.nextInt();
	
	}
}
}