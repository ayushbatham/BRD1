package Collection;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.Scanner;

public class LinkedList1 {

	Student11 s1;
    static int id;
    static String naam;
    static String dept;
    Scanner sc=new Scanner(System.in);
    LinkedList <Student11>l1=new LinkedList<Student11>();
    public void getAllData(){
 Iterator<Student11> itr=l1.iterator();
 while(itr.hasNext()){
		Student11 st=(Student11)itr.next();	
		System.out.println(" Name:-"+st.getName()+"|ID:- "+st.getId()+"|Department:- "+st.getDept());
	   }
 }
    public void setAllData(){
    	System.out.println("Enter Number of Students:-");
	    int numStudent=sc.nextInt();
    	for(int i=0;i<numStudent;i++){
    		
        	s1=new Student11();
        	System.out.println("Enter Name:-");
        	naam=sc.next();
        	s1.setName(naam);
        	System.out.println("Enter ID:-");
        	id=sc.nextInt();
        	s1.setId(id);
        	System.out.println("Enter Department-");
        	dept=sc.next();
        	s1.setDept(dept);
        	s1.Student11(naam,id,dept);
        	l1.add(s1);
        	}
    }
    public void forLinkedList(){
    	int i=1;
        while(i==1){
        System.out.println("What You Want To Do");
    	System.out.println("Enter You Choice From 1-3");
    	System.out.println("1.Add Students Data");
    	System.out.println("2.Remove Student Data");
    	System.out.println("3.Display Student Data");
    	System.out.println("***************************");
    	int choice=sc.nextInt();
    	LinkedList1 lr2=new LinkedList1(); 
    	
    	switch(choice){
    	case 1:{
    		lr2.setAllData();
    	System.out.println("Want to Display Your List?? Enter 1 For Yes");
    	int ch=sc.nextInt();
        break;
    	}
        case 2:{
        	
    		break;
    	}
    	case 3:{
    	lr2.getAllData();
    		break;
    	}
    	}
    	i--;
    	System.out.println("Want to Continue?? Enter 1 for Yes");
    	i=sc.nextInt();
    	
    	}
    }
    	

    	}


