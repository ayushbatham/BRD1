package Collection;
import java.util.*;

public class Sample {
	public static void main(String[] args){
	ArrayList<String> list=new ArrayList<String>();
	list.add("A");
	list.add("B");
	list.add("C");
	for(int i=0;i<1;i++){
		System.out.println(list);
	}
	}
	
	

}
