package Day3.q6;

class ElectricalProducts extends Product{
	double voltageRange;
	double wattage=9;
	void modify(){
		this.wattage=12;
		this.unitPrice=50;
	}
	void display(){
		System.out.println("Details: "+this.wattage+ " "+this.unitPrice); 
	}
}
public class Product {
	int productID=101;
	String name="Fan";
	int categoryID;
	double unitPrice=60;
	public static void main(String[] args) {
		ElectricalProducts e = new ElectricalProducts();
		e.display();
		e.modify();
		e.display();
	}

}
