class Test

{

static int x;

int y;

{ y = 8; } // line 1

static { x = 7 ; } //line 2

{ y = 9; } //line 3

public static void main(String []args)

{

System.out.println(x); //line 4

}

}
