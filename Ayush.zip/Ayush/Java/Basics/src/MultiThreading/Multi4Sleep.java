package MultiThreading;

public class Multi4Sleep implements Runnable {
	public void run(){
		for(int i=0;i<10;i++){
			try {
			Thread.sleep(500);
			
		} catch (InterruptedException e) {
		e.printStackTrace();
		}
			System.out.println(i);
		}
		System.out.println("Run method is running");

	}
	public static void main(String[] args) {
		Multi4Sleep m1=new Multi4Sleep();
		/*m1.run();
		m1.run();*/
		Thread t1=new Thread(m1);
		Thread t2=new Thread(m1);
		t1.start();
		try {
			t2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	}
	
	
	
	
	

