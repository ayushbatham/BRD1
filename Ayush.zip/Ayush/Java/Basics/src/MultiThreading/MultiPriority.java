package MultiThreading;

public class MultiPriority extends Thread {
	public void run(){
		for(int i=0;i<10;i++)
		{
			try {
			Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(i);
	}
	}
	
	public static void main(String[] args) {
		MultiPriority t1=new MultiPriority();
		MultiPriority t2=new MultiPriority();
		MultiPriority t3=new MultiPriority();
		t1.start();
		try {
			t1.join(1400);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t2.start();
		t3.start();
	}

}
