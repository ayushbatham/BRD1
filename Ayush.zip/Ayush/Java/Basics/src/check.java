
public class check {
	String ab="abc";

}
