package SamplePrograms;

import java.util.Scanner;
//Java Program to check callbyvalue using Array and Find its Average
class ByArr //Class used for taking array as input and calculate Average
{
	public double Av(int a[],int n)//Method takes array and it's Size as input and Returns Average of elements of integer Array
	{
		//int size=a.length;
		int sum=0;
	    double avg1;
		for(int i=0;i<n;i++){
		sum=sum+a[i];
		}
		avg1=sum/n;//calculating Average
		return avg1;
	}
}
	
public class CallByArr//main class
{
	public static void main(String args[])//main method
	{
		ByArr c1=new ByArr();//creating object of ByArr class
		Scanner sc=new Scanner(System.in);//initializing Scanner class object
		System.out.println("Enter How many numbers you want to enter:-");
		int n=sc.nextInt();//taking size of array
		
		int b[]=new int[n];//initializing array
		System.out.println("enter elements of array");
		for(int i=0;i<n;i++)//taking input from user
		{
			b[i]=sc.nextInt();
		}
	    double result=c1.Av(b,n);//saving return value of Av method in result which is returning double value
	    System.out.println("Average="+result);//Printing Average on console
	    sc.close();//closing scanner class
	}
}

