package SamplePrograms;

class Foo
{
	
static void play()
{
System.out.println("foo class static method");
Hello.play1();
}
void display()
{
System.out.println("foo class method ");
}
}
class Hello 
{
public static void play1()
{
System.out.println("hello class static method");
}

void display()
{
System.out.println("hello class method");
}
}
public class Main
{
public static void main(String[] argus)
{
	//Hello h=new Hello();
	//h.play1();
	
Foo f = new Foo();
f.play();
}
}