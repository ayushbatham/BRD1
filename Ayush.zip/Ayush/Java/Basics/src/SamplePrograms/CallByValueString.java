package SamplePrograms;
//Java program for call by value using string

public class CallByValueString //main class
{
	public void CallByValue(String BB)//CallByValue method taking a string as a parameter
	{
	BB=BB+BB;//performing concatenation on String BB
		System.out.println(BB);//printing output on console
	}

	

	public static void main(String[] args)//main method 
	{
CallByValueString c1=new CallByValueString();//initializing object c1 of CallByValeustring class
String Str="Ayush";//initializing  string value Str 
c1.CallByValue(Str);//passing String Str as parameter
c1.CallByValue("Batham");//passing a String as parameter
	}

}
