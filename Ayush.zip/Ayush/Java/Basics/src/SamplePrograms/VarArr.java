package SamplePrograms;

public class VarArr {
	public static void Check(String str,int ...b){
		System.out.println("String is:-"+str);
		System.out.println("Number of args:-"+b.length);
		
		for(int i:b){
			System.out.print(i+" ");
			
			
		}
		System.out.println();
		
	}
	public static void main(String[] args){
		
		Check("Hello",21,12,21,21,21);
	}
	
	

}
