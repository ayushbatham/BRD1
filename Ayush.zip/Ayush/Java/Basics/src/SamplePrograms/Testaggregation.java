package SamplePrograms;
//Java program to test Aggregation
public class Testaggregation//main class
{
	int id;
	String city1;
	Aggregat agg;//using Aggregat class as a data type becoz Aggregat has several variables in it
	public Testaggregation(int id, String city1, Aggregat agg)//constructor of main class
	{
		this.id=id;
		this.city1=city1;
		this.agg=agg;
	}
	void display()//method to display details
	{
		System.out.println(id+" "+city1);
		System.out.println(agg.name+" "+agg.city+" "+agg.Address);
	}
public static void main(String[] args) //main method
{
	Aggregat agg1=new Aggregat("Ayush","noida","Nirala");//making object agg1 of Aggregat class and asigning value to its parameterized constructor  
	Aggregat agg2=new Aggregat("AB","G.Noida","india");  //making object agg2 of Aggregat class and asigning value to its parameterized constructor
	  
	Testaggregation e=new Testaggregation(111,"A",agg1);//making object e of Testaggregation class and asigning value to its parameterized constructor  
	Testaggregation e2=new Testaggregation(112,"B",agg2); //making object e of Testaggregation class and asigning value to its parameterized constructor 
	      
	e.display();//calling display function  
	e2.display(); 


	}

}
