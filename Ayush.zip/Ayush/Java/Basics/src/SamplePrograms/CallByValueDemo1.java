package SamplePrograms;
//Java program of call by value using integer

public class CallByValueDemo1 //main class
{
	public void callByValue(int a)//call by value method which will take integer a as a parameter 
	{
		int sq=a*a;//performing operation on a 
		System.out.println("Square Is:-"+sq);//printing square on console
		}
public static void main(String args[])//main method
{
	CallByValueDemo1 c1=new CallByValueDemo1();//initializing object of CallByValueDemo class
	c1.callByValue(50);//passing integer value in callByValue method
}
}
