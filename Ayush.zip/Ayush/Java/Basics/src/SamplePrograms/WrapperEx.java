package SamplePrograms;
// JAva Program for converting primitive to wrapper class
public class WrapperEx {

	public static void main(String[] args) //main method
	{
		//initializing integer a
		int a=10;
		//wrapping around IntegerObject
		Integer iobj=new Integer(a);
		//initializing byte b
		byte b=1;
		//wrapping around ByteObject
		Byte bobj=new Byte(b);
		//initializing short c
		short c=12;
		//wrapping around ShortObject
		Short sobj=new Short(c);
		//initializing long d
		long d=23213;
		//wrapping around LongObject
		Long lobj=new Long(d);
		//initializing float e
		float e=1.8f;
		//wrapping around FloatObject
		Float fobj=new Float(e);
		//initializing double d
		double f=250.56;
		//wrapping around DoubleObject
		Double dobj=new Double(f);
		//initializing character g
		char gh='c';
		//wrapping around CharacterObject
		Character cobj=new Character(gh);
		
		
		 System.out.println("integer primitive to WrapperIntegerobject:-"+iobj); 
		 System.out.println("byte primitive to WrapperByteobject:-"+bobj);
		 System.out.println("short primitive to WrapperShortobject:-"+sobj);
		 System.out.println("long primitive to WrapperLongobject:-"+lobj);
		 System.out.println("float primitive to WrapperFloatobject:-"+fobj);    
		 System.out.println("double  primitive to WrapperDoubleobject:-"+dobj);
		 System.out.println("char primitive to WrapperCharacterobject:-"+cobj);
		 

	}

}
