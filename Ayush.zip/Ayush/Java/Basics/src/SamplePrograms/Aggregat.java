package SamplePrograms;
//Aggregation class
public class Aggregat//aggregation class having several variables
{
	String name,city,Address;
	public Aggregat(String name, String city, String Address)//aggregat constructor for initializing values to String variables from main methods
	{//initializing values which came as a parameter from main method
		this.name=name;
		this.city=city;
		this.Address=Address;
	}

}
