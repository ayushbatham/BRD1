package SamplePrograms;
//Java program of call by reference

class Student
{
	//initializing instance variables
	int stdid;
	String stdname;
	float marks;
public Student(int stdid, String stdname,float marks)//parameterized constructor 
{ 
	//initializing values to instance variables
	this.stdid=stdid;
	this.stdname=stdname;
	this.marks=marks;
}	
public void display()//method to display instance variables
{
	System.out.print(stdid+" "+stdname+" "+marks);
}
}	
public class CallByRef//main class
{
	public void displayMarks(Student std)//method which will take reference of object as a parameter
	{
		std.display();
	}
public static void main(String args[])//main method
{
	Student s1=new Student(1,"Ayush",75);//initializing object of Student class and giving parameters to it's constructor
	CallByRef c1=new CallByRef();//initializing object of CallByRef class which is a main class
	c1.displayMarks(s1);//passing s1 object as a reference in displaymarks method using c1 object

}
}
