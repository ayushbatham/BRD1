package SamplePrograms;
//Java Program for encapsulation and getter and setter method
public class encaps //encapsulation class having getter and setter method and private variables
{
	private String str;//private variables
	public void  setStr(String str)//setter method setting str
	{
		this.str=str;
	}
public String getStr()//getter method returning str
{
	return str;
}
public static void main(String args[])//main method
{
	encaps en=new encaps();//creating object of encaps class
	en.setStr("Ayush");//giving values to setStr method
	System.out.println(en.getStr());//geting values from getStr method and printing output to console
}
}

