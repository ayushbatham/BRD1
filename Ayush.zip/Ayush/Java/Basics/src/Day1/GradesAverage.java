package Day1;

import java.util.Scanner;

public class GradesAverage{
    private final int MIN_GRADE  = 0;
    private final int MAX_GRADE = 100;
    private int[] grades;
    Scanner in;
    private void run(int numStudents)
    {
        if (numStudents <= 0) {
            System.out.println("Invalid number of students.");
            return;
        }        
        grades = new int[numStudents];
        double sum=0;
        int    i= 0;
        while (i<numStudents)
        {
          System.out.printf("Enter the grade for student "+(i+1)+":-");
            int grade = in.nextInt();
            if ((grade >= MIN_GRADE) && (grade <= MAX_GRADE)) {
                grades[i] = grade;
                sum       =sum+ grade;
                i++;
                continue;
            }
            System.out.println("Invalid grade, try again...");
        }
        double avg=sum/numStudents;
        System.out.printf("The average is:-"+avg );
    }
    public static void main(String[] args)
    {
        GradesAverage aG = new GradesAverage();
        aG.in = new Scanner(System.in);
        System.out.print("Enter the number of students: ");
        int numStudents = aG.in.nextInt();
        aG.run(numStudents);
    }
}