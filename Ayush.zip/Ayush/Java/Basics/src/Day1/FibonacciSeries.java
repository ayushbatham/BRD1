package Day1;
//Java Program to display the first 20 Fibonacci numbers And Display their Average
public class FibonacciSeries//public class
{
	public static void fibonacci() //static method to find fibonacci
	{
		System.out.println("First 20 Fibonacci Numbers Are:-");
	    System.out.print("0 1 ");//printing first two numbers
	           int a = 0;//initializing a=0
	           int b = 1;//initializing b=0
	           int sum1=0;//initializing sum1=0
	           for (int i = 1; i < 20; i++)//for loop to find fibonacci numbers 
	         {
	        	   int next1 = a + b;//saving previous two in next
	               sum1=sum1+next1;//saving value of next in sum to calculate average 
	               System.out.print(next1 + " ");//printing next
	               a = b;//initializing value of b in a
	               b = next1;//initializing value of next in b
	           }
	           System.out.println();
	           double avg=sum1/20;//calculating average
	           System.out.println("Average Is:-"+avg);//printing average
	       }
	public static void main(String[] args) //main method
	{
	       fibonacci();//calling fibonacci function to generate output
	   }
	   }
	
