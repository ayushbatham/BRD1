package Day1;
/*Java Program to print
1
1 2
1 2 3
1 2 3 4
1 2 3 4 5
1 2 3 4 5 6
1 2 3 4 5 6 7
1 2 3 4 5 6 7 8*/
public class Pattern//main class
{

	public static void main(String[] args)//main method 
	{
		 int n = 9;
		 
	        for (int i = 0; i <n; i++)//loop to set j 
	        {
	            for (int j = 1; j <= i; j++)//for loop to print numbers
	                {System.out.print(j);//printing value of j
	                }
	            System.out.println();//printing next line after every loop
	        }
	  }
}
