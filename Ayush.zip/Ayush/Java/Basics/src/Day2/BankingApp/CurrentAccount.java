package Day2.BankingApp;

public class CurrentAccount extends Account {
	private int TRADELICNO;
	private final int MAX_WITHDRAW_LIMIT=25000;
	
	public CurrentAccount(int LICNO){
		TRADELICNO=LICNO;
	}
	public int getTradeLicenceNumber(){
		return TRADELICNO;
	}
	public void getAmount(){
		
	}
	public void withdraw0(double amount){
		if(amount<MAX_WITHDRAW_LIMIT){
			if(amount<getAccountBalance()){
				super.setAccountBalance(getAccountBalance()-amount);
     			}
			else{
				System.out.println("Does Not Have Sufficient Balance");
			}
		}
		else
		{
		 System.out.println("amonunt exceeds withdraw limit");
		}	
    }
	public void depositAmount(double amount){
		super.setAccountBalance(getAccountBalance()+amount);
	}
}
