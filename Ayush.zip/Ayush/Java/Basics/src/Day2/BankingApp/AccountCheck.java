package Day2.BankingApp;
import java.util.Scanner;
public class AccountCheck {

	public static void main(String[] args) {
		System.out.println("Which Account You Want To Create");
		System.out.println("1.Saving Account");
		System.out.println("2.Current Account");
		Scanner sc=new Scanner(System.in);
		int ch=sc.nextInt();
		String choice="y";
		switch(ch){
		case 1: 
			System.out.println("Saving Account");
			Account ac1=new SavingAccount("Ayush",500);
			ac1.deposit(500.0);
			break;
		case 2:
			System.out.println("Current Account");
			Account ac2=new CurrentAccount(4556);
			ac2.deposit(855);
			break;
		default :
			break;
		
		}
System.out.println("1.Input 1 for Deposit Money");
System.out.println("2.Input 2 for Withdraw Money");
System.out.println("3.Show Current Balance");
System.out.println("0 for exit");
while(choice=="y"||choice=="Y"){
	int x=sc.nextInt();
	if(ch==1){
		switch(x){
		
		case 1:
			System.out.println("Enter Amount:-");
			double b=sc.nextDouble();
			Account ac=new SavingAccount("Ayush",500);
			ac.deposit(b);
			break;
		
		case 2:
			System.out.println("Enter Withdraw Amount:-");
			int c=sc.nextInt();
			SavingAccount sa1=new SavingAccount("Ayush",500);
			sa1.withdraw(c);
			break;
		case 3:
            Account ac2=new SavingAccount("Ayush",1500);
            ac2.display();
            break;
		case 0:
			System.out.println("Thank You");
			System.exit(0);
            break;   
		default:
        	break;
        }
	}
	System.out.println("Want to continue??");
	choice=sc.next();
    }
}

}
