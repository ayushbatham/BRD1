package Day2.BankingApp;

public class SavingAccount extends Account {
	private final double MIN_BAL=1000;
	private final double MAX_WITHDRAW_LIMIT=20000;
	private final double INTEREST=1.05;
	private double tempo;
	public SavingAccount(String accountHolderName,double accountBalance){
		super(accountHolderName,accountBalance);
		
	}
	public void withdraw(double amount){
		if(amount<MAX_WITHDRAW_LIMIT){
			if((getAccountBalance()-amount<MIN_BAL)){
				System.out.println("Could not withdraw money due to minimus balance");
			 }
		setAccountBalance(getAccountBalance()-amount);
		}
	 }
	public double getBalance(){
		tempo=getAccountBalance()*INTEREST;
		return tempo;
	}
	
}


