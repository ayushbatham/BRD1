package Day2.BankingApp;
import java.util.Random;
	public  abstract class Account {
		protected String accountHolderName;
		private int accountNumber;
		private double accountBalance;
	public Account()
		{
		}
	public Account(String accountHolderName,double accountBalance){
		Random rand=new Random();
	    String num=1000+rand.nextInt(89999)+"";	
		this.accountNumber=Integer.parseInt(num);
		this.accountHolderName=accountHolderName;
		this.accountBalance=accountBalance;
		}
	public void setAccountHolderName(String accountHolderName){
		this.accountHolderName=accountHolderName;
	    }
	public String getAccountHolderName()
	{
		return accountHolderName;
	}
	 public void setAccountNumber(int accountNumber){
		this.accountNumber=accountNumber;
	    }
	 public int getAccountNumber(){
		 return accountNumber;
	 }
	public void setAccountBalance(double accountBalance){
		this.accountBalance=accountBalance;
	    }
	public double getAccountBalance(){
		return accountBalance;
	    }
	public void deposit(double amount){
		accountBalance +=amount;
		System.out.println("Balance Is:-"+accountBalance);
	}
	public void display(){
		System.out.println("Account Holder Name:-"+getAccountHolderName());
		System.out.println("Account Balance:-"+getAccountBalance());
		System.out.println("Account Number:-"+getAccountNumber());
	}
}


