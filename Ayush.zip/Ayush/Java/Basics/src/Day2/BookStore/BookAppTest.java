package Day2.BookStore;


import java.util.Scanner;

public class BookAppTest {

	public static void main(String args[]) {
		BookStore book1 = new BookStore();
		book1.initialise();
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter option: 1."); 
		System.out.println("to display all the books"); 
		System.out.println("2.to order the books");
		System.out.println("3. sell the books");

		int ch;
		ch=sc.nextInt();
	    switch(ch){
		case 1:
			book1.display();
			break;
		case 2:
			book1.order("abc", 100);
			break;
		case 3:
			book1.sell("Race 3", 50);
			break;
		case 0:
			System.exit(0);
			break;
		default:
			System.out.println(" Wrong Input!!");

		}
		sc.close();

	}

}