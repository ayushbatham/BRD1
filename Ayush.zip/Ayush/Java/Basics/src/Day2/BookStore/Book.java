package Day2.BookStore;

public class Book {

	private String bookTitle;
	private String bookAuthor;
	private String bookISBN;
	private int bookCopies;
	
	Book()
	{
	this("null","null","null",0);	
	}
	Book(String bookTitle,String bookAuthor, String bookISBN, int bookCopies)
	{
		this.bookTitle=bookTitle;
		this.bookAuthor=bookAuthor;
		this.bookISBN=bookISBN;
		this.bookCopies=bookCopies;
	}
	
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getBookAuthor() {
		return bookAuthor;
	}
	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}
	public String getBookISBN() {
		return bookISBN;
	}
	public void setBookISBN(String bookISBN) {
		this.bookISBN = bookISBN;
	}
	public int getBookCopies() {
		return bookCopies;
	}
	public void setBookCopies(int bookCopies) {
		this.bookCopies = bookCopies;
	}
	public void display()
	{
		System.out.println("Book title is :"+ bookTitle);
		System.out.println("Book author is :"+ bookAuthor);
		System.out.println("Book ISBN is :"+ bookISBN);
		System.out.println("No. of copies are :"+ bookCopies);	
	}
}


