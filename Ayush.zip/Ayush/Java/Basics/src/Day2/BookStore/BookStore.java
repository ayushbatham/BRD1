package Day2.BookStore;
import java.util.Scanner;

public class BookStore extends Book{
	int numBooks;
	String Title, Author, ISBN;
	int copies;

	Book[] book12;

	public void initialise() {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter total no. of books you want to enter");
		numBooks = sc.nextInt();
		book12 = new Book[numBooks];
		for (int i = 0; i <numBooks; i++) {
			System.out.println("enter title");
			Title = sc.next();
			System.out.println("enter author");
			Author = sc.next();
			System.out.println("enter isbn");
			ISBN = sc.next();
			System.out.println("enter copies");
			copies = sc.nextInt();
			book12[i] = new Book(Title, Author, ISBN, copies);
		}
		//sc.close();
	}

	public void sell(String Title, int copies) {
		for (int i = 0; i < numBooks; i++) {
			if ((book12[i].getBookTitle().equals(Title))
					&& (book12[i].getBookCopies() >= copies)) {
				book12[i].setBookCopies(book12[i].getBookCopies() - copies);
				break;

			} else {
				System.out.println("Book not found !!");
			}
		}
	}

	public void order(String isbn, int copies) {
		for (int i = 0; i < 1; i++) {
			if ((book12[i].getBookISBN().equals(isbn))) {
				book12[i].setBookCopies(book12[i].getBookCopies() + copies);
				display();
				
			} else {
				i++;
				Scanner sc2 = new Scanner(System.in);
				System.out.println("enter title \n");
				Title = sc2.nextLine();
				System.out.println("enter author \n");
				Author = sc2.nextLine();
				System.out.println("enter isbn \n");
				ISBN = sc2.nextLine();
				System.out.println("enter copies \n");
				copies=sc2.nextInt();
				book12[i] = new Book(Title, Author, ISBN, copies);
				numBooks++;
				display();
				sc2.close();
			}
		}
	}

	public void display() {

		for (int j = 0; j < numBooks; j++) {
			System.out.println("Book title is " + book12[j].getBookTitle());
			System.out.println("enter author " + book12[j].getBookAuthor());
			System.out.println("enter isbn" + book12[j].getBookISBN());
			System.out.println("enter copies" + book12[j].getBookCopies());
		}
	}
}
