package Day2.Overide;


public abstract class Car extends Vehical{
	private int noOfDoor;

	public Car(int noofVeh, int noofpassenger, int model, String make, int noOfDoor) {
		super( noofVeh,  noofpassenger,  model,  make);
		this.noOfDoor = noOfDoor;
	}
	
	public void display(){
		System.out.println("no of Doors: " + noOfDoor);
		super.display();
	}
	

}
