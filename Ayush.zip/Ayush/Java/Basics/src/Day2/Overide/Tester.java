package Day2.Overide;


import java.util.Scanner;

public class Tester {
	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		System.out.println("PE 1. for sports car 2 for Convertable car");
		Vehical vehical=null;
		int choice=scanner.nextInt();
		
		switch (choice) {
		case 1:
			vehical=new ConvertableCar(4, 2, 3, "indian", 4, true);
			vehical.display();
			break;

		case 2:
			vehical=new SportCar(4, 2, 3, "indian", 2);
			vehical.display();
		default:
			break;
		}
		
	}

}
