package Day2.Overide;

public class ConvertableCar extends Car {
	

	private boolean isHoodOpen;
	
	public ConvertableCar(int noofVeh, int noofpassenger, int model,String make, int noOfDoor, boolean isHoodOpen) {
		super(noofVeh, noofpassenger, model, make, noOfDoor);
		this.isHoodOpen=isHoodOpen;
	}

	public void display(){
		System.out.println("isHoodOpen: " + isHoodOpen);
		super.display();
	}
	
}
