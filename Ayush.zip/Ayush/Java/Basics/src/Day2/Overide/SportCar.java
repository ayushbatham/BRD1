package Day2.Overide;

public class SportCar extends Car{

	public SportCar(int noofVeh, int noofpassenger, int model, String make,int noOfDoor) {
		super(noofVeh, noofpassenger, model, make, noOfDoor);
	}
	
	public void display(){
		super.display();
	}
	

}
