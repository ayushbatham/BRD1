package Day2.Overide;

public abstract class Vehical {
	private int noofVeh;
	private int noofpassenger;
	private int model;
	private String make;
	public Vehical(int noofVeh, int noofpassenger, int model, String make) {
		super();
		this.noofVeh = noofVeh;
		this.noofpassenger = noofpassenger;
		this.model = model;
		this.make = make;
	}
	public int getNoofVeh() {
		return noofVeh;
	}
	public void setNoofVeh(int noofVeh) {
		this.noofVeh = noofVeh;
	}
	public int getNoofpassenger() {
		return noofpassenger;
	}
	public void setNoofpassenger(int noofpassenger) {
		this.noofpassenger = noofpassenger;
	}
	public int getModel() {
		return model;
	}
	public void setModel(int model) {
		this.model = model;
	}
	public String getMake() {
		return make;
	}
	public void setMake(String make) {
		this.make = make;
	}
	
	public void display(){
		System.out.println(getMake());
    	System.out.println(getModel());
    	System.out.println(getNoofpassenger());
	}
	
	
}
