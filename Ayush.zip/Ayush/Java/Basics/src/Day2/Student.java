package Day2;

public class Student {
	public String name;
	public String id;
	public double grade;
	public Student(String name,String id, double grade){
		
		this.name=name;
		this.id=id;
		this.grade=grade;
		}
	public Student(String name,String id){
		this(name,id,0.0);
		this.name=name;
		this.id=id;
	}
	public Student(String id){
		this(null,id,0.0);
		this.id=id;
	}
	public void display(){
    System.out.println("Name"+name+"ID"+id+"Grade"+grade);
	}
	public void display1(int year){
		display();
		
	}
	

}
