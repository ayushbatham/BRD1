package Day2;

import java.util.Scanner;

public class ApplicationStudent    {
	public static void main(String[] args){
		int choice;
		//String ch;
		String name;
		String id;
		int year;
		double grade;
    Scanner sc=new Scanner(System.in);
	Student st=null;
	do{
	System.out.println("Enter What You Want to do");
     System.out.println("1.To Create Student Object");
		System.out.println("2.To Display");
	choice=sc.nextInt();
	switch(choice){
	case 1:
		System.out.println("Enter Name");
		name=sc.nextLine();
		System.out.println("Enter id");
		id=sc.nextLine();
		System.out.println("Enter Grade");
		grade=sc.nextDouble();
		st=new Student(name,id,grade);
		break;
	
	case 2:
		if(st==null){
			System.out.println("First create Student object");
		}
		else{
		    System.out.println("Enter year");
			year=sc.nextInt();
			if(year==2018){
			 st.display1(year);
			}
			else{
				System.out.println("Please Enter valid Year");
				}
			}
		break;
    default:
    	break;
	}
	}while(choice==1||choice==2);
	}
}