package modifier;

class mod1//default class
{
	
 void display1()//default method
 {
	 System.out.println("default class");
 }
}
public class mod//public class
{
	public void display2()//public method
	{
		System.out.println(" public is invoked");
	}
	protected void display3()//protected method
	{
		System.out.println("protected method");
	}
  private void display4()//private method
  {
	 System.out.println("private method");
	 }
  
}


