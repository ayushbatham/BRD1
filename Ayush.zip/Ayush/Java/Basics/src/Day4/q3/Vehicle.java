package Day4.q3;

import java.util.Scanner;

public class Vehicle {
	static String modelOfCategory(String str){
		if(str.equals(str)){
		 str = "TATA "+str;
		}
		return str;
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Model from the available choices: "+ "\n" +"SUV"+ "\n" +"SEDAN"+ "\n" +"ECONOMY"+ "\n" +"MINI");
		String str = sc.nextLine();
		if(str.equals("SUV")|| str.equals("SEDAN") || str.equals("ECONOMY" )|| str.equals("MINI"))
			System.out.println(modelOfCategory(str));
		else
			System.out.println("Choose from the given category");
		
	}

}
