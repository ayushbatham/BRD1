package Day4.q2;
import java.util.Scanner;
class Door extends Office{}
class Window extends Office{}
class Conversation extends Office{}
class BankAccount extends Office{}
class Box extends Office{}
public class Office {
	void open(Office c){
		System.out.println(c.getClass().getSimpleName()+" opened.");
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number to open :");
		System.out.println("1 for Door"+"\n"+"2 for Window"+"\n"+"3 for Conversation"+"\n"+"4 for Bank Account"+ "\n" +"5 for Box");
		int n = sc.nextInt();
		switch(n){
		case 1:
			Office c = new Door();
			c.open(c);
			break;
		case 2:
				c = new Window();
				c.open(c);
			break;
		case 3:
			c = new Conversation();
			c.open(c);
			break;
		case 4:
			c = new BankAccount();
			c.open(c);
			break;
		case 5:
			c = new Box();
			c.open(c);
			break;
		}
		String str = sc.nextLine();
	}

}
