package jdbccheck;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.ConnectionSetup;

public class Signin {
	ConnectionSetup con1=new ConnectionSetup();
	@SuppressWarnings("resource")
	public boolean Signin1(int id1,String pwd1){
		ConnectionSetup con1=new ConnectionSetup();
		Connection con=con1.getConnection();
	    PreparedStatement pstmt2=null;
		ResultSet resultSet=null;
        try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:Oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
				pstmt2=con.prepareStatement("Select * from SIGNINSIGNUP");
				resultSet=pstmt2.executeQuery();
				pstmt2=con.prepareStatement(" Select * from SIGNINSIGNUP where userid=? and password=?");
				pstmt2.setInt(1, id1);
				pstmt2.setString(2, pwd1);
				resultSet=pstmt2.executeQuery();
				while(resultSet.next()){
				int id2=resultSet.getInt("userid");
				String pwd2=resultSet.getString("password");
				if((id1==id2)&& pwd1.equalsIgnoreCase(pwd2)){
					return true;					
				}
				
               }
        }catch (SQLException e) {
                 e.printStackTrace();
	}catch (ClassNotFoundException e) {

		e.printStackTrace();
	}
finally{
	con1.closeConnection();
	try {
		pstmt2.close();
		resultSet.close();
	} catch (SQLException e) {
		
		e.printStackTrace();
	}
}
		return false;
		

}

}

