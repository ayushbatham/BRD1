package jdbccheck;
import com.nucleus.connection.*; 

import java.sql.*;
import java.util.Scanner;

public class Signup {
	
	ConnectionSetup con1=new ConnectionSetup();
	
	public void SignUp1(int userid,String fname,String lname,String email,String pwd){
		Connection con=con1.getConnection();
	    PreparedStatement pstmt2=null;
		ResultSet resultSet=null;
		Scanner sc=new Scanner(System.in);
        try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:Oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
				pstmt2=con.prepareStatement("Select * from SIGNINSIGNUP");
				resultSet=pstmt2.executeQuery();
				pstmt2=con.prepareStatement("insert into SIGNINSIGNUP values(?,?,?,?,?)");
                pstmt2.setInt(1, userid);
				pstmt2.setString(2, fname);
		        pstmt2.setString(3, lname);
		        pstmt2.setString(4, email);
		        pstmt2.setString(5, pwd );
				int i=0;
				try{
					pstmt2.executeUpdate();
				}catch(Exception e){
					i++;
				    if(i==1){System.out.println("User Already Exists ");}
				}
				if(i==0){
					System.out.println("*****Signed Up Successfully*****");
				}
                 
			} catch (SQLException e) {

				e.printStackTrace();
			}catch (ClassNotFoundException e) {

				e.printStackTrace();
			}
             finally{
        	con1.closeConnection();
        	try {
				pstmt2.close();
				resultSet.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	
        	
        }
	}
}
