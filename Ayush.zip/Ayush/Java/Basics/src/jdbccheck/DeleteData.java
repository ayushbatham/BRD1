/*package jdbccheck;
import java.sql.*;
import java.util.Scanner;

public class DeleteData {
	public boolean deldata(int id){
    
    Connection con=null;
    PreparedStatement pstmt2=null;
	ResultSet resultSet=null;
	Scanner sc=new Scanner(System.in);
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		con=DriverManager.getConnection("jdbc:Oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
		pstmt2=con.prepareStatement("Select * from SIGNINSIGNUP");
		resultSet=pstmt2.executeQuery();
		pstmt2=con.prepareStatement("Select * from where userid=? and firstname=?");
	
		
		
	}catch (SQLException e) {
            e.printStackTrace();
        }catch (ClassNotFoundException e) {
              e.printStackTrace();
         }
          finally{
                 try {
                     con.close();
                     pstmt2.close();
                     resultSet.close();
                     } catch (SQLException e) {
                           e.printStackTrace();
                           }
          }

}
}
*/