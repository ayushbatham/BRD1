package jdbccheck;

import java.util.Scanner;

public class jdbcDemo {

	public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
		int choice=0;
		int i=1;
		while(i==1){
		System.out.println("Enter 1 to Sign Up:-");
		System.out.println("Enter 2 to Sign In:-");
		System.out.println("Enter 3 to Display Data:-");
		System.out.println("Enter 4 to Update Data:-");
		System.out.println("Enter 5 to Delete Data:-");
		choice=sc.nextInt();
        switch (choice) {
				case 1:
				{
					int userid;
				    String fname,lname,email,pwd;
					System.out.println("Enter ID:-");
					userid=sc.nextInt();
					System.out.println("Enter First Name:-");
					fname=sc.next();
					System.out.println("Enter Last Name:- ");
					lname=sc.next();
					System.out.println("Enter Email Id:-");
					email=sc.next();
					System.out.println("Enter Password:-");
					pwd=sc.next();
					Signup signup=new Signup();
					signup.SignUp1(userid, fname, lname, email, pwd);
				break;
				}
				case 2:{
					int id1;
					String pwd1;
					Signin signin=new Signin();
					System.out.println("Enter UserID:-");
					id1=sc.nextInt();
					System.out.println("Enter Password:-");
					pwd1=sc.next();
					if(signin.Signin1(id1,pwd1)==true){
						System.out.println("*****Signed In Successfully*****");
					}
					else{
						System.out.println("User Not Exist ,PLEASE SIGNUP");
					}
					break;
		        }
				case 3:
				{
					DisplayData ds=new DisplayData();
					ds.DisplayData1();
			        break;
				}
				case 4:
				{
//					DeleteData del=new DeleteData();
//					del.deldata();
					break;
				}
                default:
					break;
				}
                i--;
                System.out.println("FOR MENU Press 1");
                i=sc.nextInt();
		}
		sc.close();
		}
}
		