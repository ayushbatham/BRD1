package jdbccheck;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nucleus.connection.ConnectionSetup;
public class DisplayData {
	ConnectionSetup con1=new ConnectionSetup();
	public void DisplayData1(){
		Connection con=con1.getConnection();
	    PreparedStatement pstmt2=null;
		ResultSet resultSet=null;
		try {
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con=DriverManager.getConnection("jdbc:Oracle:thin:@10.1.50.198:1521:orcl","sh","sh");
				pstmt2=con.prepareStatement("Select * from SIGNINSIGNUP");
				resultSet=pstmt2.executeQuery();
				while(resultSet.next()){
					int id=resultSet.getInt(1);
					String fname=resultSet.getString(2);
					String lname=resultSet.getString(3);
					String email=resultSet.getString(3);
					System.out.println("Userid:- "+id+"||First Name:- "+fname+"||Last Name:- "+lname+"||Email:- "+email);
					}
	        }catch (SQLException e) {
                  e.printStackTrace();
              }catch (ClassNotFoundException e) {
                    e.printStackTrace();
               }
                finally{
                       try {
                           con1.closeConnection();
                           pstmt2.close();
                           resultSet.close();
                           } catch (SQLException e) {
                                 e.printStackTrace();
                                 }
                }
	}
	}


