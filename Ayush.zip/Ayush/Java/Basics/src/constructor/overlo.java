package constructor;

public class overlo //constructor overloading
{
	public overlo()//no argument constructor
	{
		System.out.println("No argument constructor invoked");
	}
	public overlo(int n)//single argument constructor
	{
		int square;
		square=n*n;//square of n
		System.out.println(square);
	}
	public overlo(int x,int y)//two argument constructor
	{
		System.out.println(x*y);
	}
	public overlo(int x, int y,int z) //three arguments constructor
	{
		System.out.println(x+y+z);
		
	}

}
