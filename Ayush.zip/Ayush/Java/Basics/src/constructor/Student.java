package constructor;

public class Student //constructor chaining
{
	public Student()//no argument constructor
	{
		
		this(5);//calling single argument constructor or current class single argument constructor
		System.out.println("Default constructor");
	}
	public Student(int n)//single argument constructor
	{
		this(5,7);//calling current class two argument constructor
		System.out.println(n);
	}
	public Student(int x,int y)//two argument constructor
	{
		
		System.out.println(x*y);
		}

}

