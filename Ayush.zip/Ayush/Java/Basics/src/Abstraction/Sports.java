package Abstraction;

abstract class Activity {
	abstract void run();
	 abstract void excercise();
	 abstract void walk();

}
class Activity1 extends Activity{
	void run(){
		System.out.println("Running");
	}
	void excercise(){
		System.out.println("Doing Excercise");
		
	}
	void walk(){
		System.out.println("Walking");
	}
	
}
public class Sports{
	public static void main(String[] args){
		Activity a1=new Activity1();
		a1.run();
		a1.excercise();
		a1.walk();

	}
}
