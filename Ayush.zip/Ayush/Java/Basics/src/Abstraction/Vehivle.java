package Abstraction;
abstract class Vehicle{
	Vehicle(){
		System.out.println("Different Type Of Vehicles and Their Attributes are");
	}
	abstract void Type();
	abstract void Colour();
	abstract void VehicleNumber();
}
abstract class Bike extends Vehicle{
	
	
}

public class Vehivle {
	public static void main(String[] args){
		
	}

}
