package com.nucleus.modelPackage;

public class CustomerClass11DaoXml implements CustomerClass11Dao {

	public CustomerClass11 readFromFile(String fileLocationName,String rejectionLevel) {
		// TODO Auto-generated method stub
		return null;
	}

	public void tableWrite(CustomerClass11 customerClass11,String rejectionLevel) {
		// TODO Auto-generated method stub
		
	}

}
